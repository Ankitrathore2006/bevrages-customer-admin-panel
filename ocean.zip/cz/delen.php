<?php
include("session.php"); 

include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $daily_challan_id = $_GET['daily_challan_id'];   
    $daily_credit_id = $_GET['daily_credit_id'];   
    $daily_exp_id = $_GET['daily_exp_id'];  
    $gadi_no = $_GET['gadi_no'];
    $date = $_GET['date'];

    // $sql_credit = "DELETE FROM `daily_credit` WHERE `id` = '$daily_credit_id'"; 
    // $result_credit = mysqli_query($conn, $sql_credit);

    // $sql_credit_sm = "DELETE FROM `daily_credit` WHERE `id` = '$daily_credit_id'"; 
    // $result_credit_sm = mysqli_query($conn, $sql_credit_sm);

    // $sql_exp = "DELETE FROM `daily_exp` WHERE `id` = '$daily_exp_id'"; 
    // $result_exp = mysqli_query($conn, $sql_exp);

    // $sql_challan = "DELETE FROM `daily_challan` WHERE `id` = '$daily_challan_id'"; 
    // $result_challan = mysqli_query($conn, $sql_challan);

    if ($result_credit && $result_credit_sm && $result_exp && $result_challan) {
        echo "<script>
                alert('Successfully Deleted!');
                window.location.href='delen.php?gadi_no=" . $gadi_no . "&date=" . $date . "';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
}
?>

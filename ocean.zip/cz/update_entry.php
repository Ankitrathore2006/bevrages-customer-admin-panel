<?php
include("session.php"); 

include("db.php");
// include("header.php");
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect URL parameters
    $driver_name = $_GET['driver_name'];
    $driver_morning_time = $_GET['driver_morning_time'];
    $driver_evening_time = $_GET['driver_evening_time'];
    $driver_wake_up = $_GET['driver_wake_up'];
    $driver_new_party = $_GET['driver_new_party'];
    $driver_total_box = $_GET['driver_total_box'];
    $driver_trip = $_GET['driver_trip'];
    $driver_bottle_box_cap = $_GET['driver_bottle_box_cap'];
    $driver_dress = $_GET['driver_dress'];
    $driver_max_profit = $_GET['driver_max_profit'];
    $driver_max_avg_price = $_GET['driver_max_avg_price'];
    // $driver_total_creadit=$_GET['salesman_total_creadit'];

    $salesman_name = $_GET['salesman_name'];
    $salesman_morning_time = $_GET['salesman_morning_time'];
    $salesman_evening_time = $_GET['salesman_evening_time'];
    $salesman_wake_up = $_GET['salesman_wake_up'];
    $salesman_new_party = $_GET['salesman_new_party'];
    $salesman_total_box = $_GET['salesman_total_box'];
    $salesman_trip = $_GET['salesman_trip'];
    $salesman_bottle_box_cap = $_GET['salesman_bottle_box_cap'];
    $salesman_dress = $_GET['salesman_dress'];
    $salesman_max_profit = $_GET['salesman_max_profit'];
    $salesman_max_avg_price = $_GET['salesman_max_avg_price'];
    // $salesman_total_creadit=$_GET['salesman_total_creadit'];

    $gadi_no = $_GET['gadi_no'];
    $gadi_exp = $_GET['gadi_exp'];
    $diesel = $_GET['diesel'];
    $toll = $_GET['toll'];
    $s_man = $_GET['s_man'];
    $chai_pani = $_GET['chai_pani'];
    $other_exp = $_GET['other_exp'];
    // $total_exp = $_GET['total_exp'];
    $name = $_GET['name'];
    $gadi_date = $_GET['gadi_date'];
    $old_date = $_GET['old_date'];

    $challan_no = $_GET['challan_no'];
    $case = $_GET['case'];
    $account = $_GET['account'];
    $udhari = $_GET['udhari'];
    $one_liter = $_GET['one_liter'];
    $half_liter = $_GET['half_liter'];
    $quarter_liter = $_GET['quarter_liter'];
    $two_liter = $_GET['two_liter'];
    $cold_drink = $_GET['cold_drink'];
    $gadi_route = $_GET['gadi_route'];
    // $discount = $_GET['Discount'];

    // Update `daily_credit` for Driver
    $sql_credit = "UPDATE `daily_credit` SET `emp_name`='$driver_name', `mt`='$driver_morning_time', `et`='$driver_evening_time', `wate`='$driver_wake_up', `new_party`='$driver_new_party', `total_box`='$driver_total_box', `trip1/2`='$driver_trip', `b/c`='$driver_bottle_box_cap', `dress`='$driver_dress', `max_profit`='$driver_max_profit', `max_average`='$driver_max_avg_price',`date`='$gadi_date' WHERE `gadi_no`='$gadi_no' AND `date`='$old_date' AND `role`='Driver'";
    $result_credit = mysqli_query($conn, $sql_credit);

    // Update `daily_credit` for Salesman
    $sql_credit_sm = "UPDATE `daily_credit` SET `emp_name`='$salesman_name', `mt`='$salesman_morning_time', `et`='$salesman_evening_time', `wate`='$salesman_wake_up', `new_party`='$salesman_new_party', `total_box`='$salesman_total_box', `trip1/2`='$salesman_trip', `b/c`='$salesman_bottle_box_cap', `dress`='$salesman_dress', `max_profit`='$salesman_max_profit', `max_average`='$salesman_max_avg_price',`date`='$gadi_date' WHERE `gadi_no`='$gadi_no' AND `date`='$old_date' AND `role`='Salesman'";
    $result_credit_sm = mysqli_query($conn, $sql_credit_sm);

    // Update `daily_exp`
    $sql_exp = "UPDATE `daily_exp` SET `gadi_exp`='$gadi_exp', `diesel`='$diesel', `toll`='$toll', `s_man`='$s_man', `chai_pani`='$chai_pani', `other_exp`='$other_exp', `salesman_name`='$salesman_name', `driver_name`='$driver_name',`date`='$gadi_date' WHERE `gadi_no`='$gadi_no' AND `date`='$old_date'";
    $result_exp = mysqli_query($conn, $sql_exp);

    // Update `daily_challan`
    $sql_challan = "UPDATE `daily_challan` SET `salesman`='$salesman_name', `driver`='$driver_name', `1l`='$one_liter', `500ml`='$half_liter', `250ml`='$quarter_liter', `2l`='$two_liter', `coldd`='$cold_drink', `challan_no`='$challan_no', `gadi_route`='$gadi_route', `d_cash`='$case', `d_online`='$account', `udari`='$udhari', `Name`='$name',`date`='$gadi_date' WHERE `gadi_no`='$gadi_no' AND `date`='$old_date'";
    $result_challan = mysqli_query($conn, $sql_challan);

    if ($result_credit && $result_exp && $result_credit_sm && $result_challan) {
        echo "<script>
                alert('Successfully Updated!');
                window.location.href='edit_entry.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
}
?>

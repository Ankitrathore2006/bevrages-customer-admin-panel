<?php
include("session.php"); 

include("db.php");
?>
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect URL parameters
    $gadi_name = $_GET['gadi_name'];
    $gadi_no = $_GET['gadi_no'];
    $gadi_no = strtoupper($gadi_no);
    $j_date = $_GET['j_date'];

    // Insert into `daily_challan`
    $sql_challan = "INSERT INTO `gadi_detail`(`gadi_no`, `company`, `date`) VALUES
    ('$gadi_no','$gadi_name','$j_date')";
    $result_challan = mysqli_query($conn, $sql_challan);

    if ($result_challan) {
        echo "<script>
                alert('Successfully Added!');
                window.location.href='add_gadi.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
}

?>
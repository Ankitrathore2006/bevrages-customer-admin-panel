<?php
include("session.php"); 

$active =16;
include("db.php");
if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}
?>


<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Employee performance</li>
    </ol>
</div>


<div class="row m-4 d-flex justify-content-center align-items-center">

    <div class="col-lg-7 my-4">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                    <h6 class="mb-0"> Select any detail : </h6>
                </div>
                <div class="card-body p-3 d-flex flex-column justify-content-evenly gap-3 align-items-center">

                    <div class="w-60" style="display: flex;justify-content: space-around;">
                        <div class="form-group w-100"style="display: flex; gap: 1rem; justify-content: space-evenly;">
                            <a class="w-50" href="emp_performance1.php?w=l"><button type="button" class="btn btn-success" style="width: 100%;">Last week</button></a>
                            <a class="w-50" href="emp_performance1.php?w=c"><button type="button" class="btn btn-success" style="width: 100%;">This week</button></a>
                            
                        </div>
                    </div>
                    <form class="w-50" autocomplete="off" method="get" action="emp_performance1.php">
                    <div  style="display: flex;justify-content: space-around;">
                        <div class="form-group w-100"style="display: flex; justify-content: space-evenly;">
                            <button type="button" class="btn btn-success" onclick="btn2()" style="width: 49%;">Month</button>
                            <button type="button" class="btn btn-success" onclick="btn1()" style="width: 49%;">Range</button>
                            
                        </div>
                    </div>
                    
                    
                <div id="stu1" class="w-100" style=" display: none;">
                    <label style="margin-bottom: 8px;">Select date range : </label>
                    <div class="form-group ">
                        <label for="exampleFormControlInput1" style="margin-bottom: 8px;">From : </label>
                        <input type="date" name="from" class="form-control" id="f_date">
                    </div>
                    <div class="form-group ">
                        <label for="exampleFormControlInput1" style="margin-bottom: 8px;">To : </label>
                        <input type="date" name="to" class="form-control" id="t_date">
                    </div>
                </div>
                
                <div id="sta1" class="w-100" style=" display: block;">
                    <div class="form-group ">
                        <label for="exampleFormControlInput1" style="margin-bottom: 8px;">Month : </label>
                        <input type="month" name="date" class="form-control" id="d_date">
                    </div>
                </div>

                 <div style="display: flex; justify-content: center;" class="row-1  d-flex mb-4 ">
                    <button type="submit" class="btn btn-primary ">Submit</button>
                </div>
                </form>
            </div>
       
    </div>

</div>

<?php
        include("footer.php");
?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
<script>
const employeeName = document.getElementById('employee_name');
const challanNo = document.getElementById('challan_no');
// const gadi_no = document.getElementById('gadi_no');
const pr_ch_no = challanNo.value;

employeeName.addEventListener('change', function() {
    if (employeeName.value === 'plant sale') {
        challanNo.value = 0;
    } else {
        challanNo.value = pr_ch_no;
    }
});


function resetSelectElement(selectElement) {
    selectElement.selectedIndex = 0;
}

function btn2() {
    const form = document.getElementById('sta1');
    const form1 = document.getElementById('stu1');

    if (form.style.display === 'none' && form1.style.display === 'block') {
        const employeeName = document.getElementById('employee_name');
        form.style.display = 'block';
        form1.style.display = 'none';
        resetSelectElement(employeeName);
        challanNo.value = pr_ch_no;
    }
}

function btn1() {
    const form = document.getElementById('sta1');
    const form1 = document.getElementById('stu1');

    if (form.style.display === 'block' && form1.style.display === 'none') {
        const driverName = document.getElementById('driverName');
        const salesmanName = document.getElementById('salesmanName');
        form.style.display = 'none';
        form1.style.display = 'block';
        resetSelectElement(driverName);
        resetSelectElement(salesmanName);
        challanNo.value = pr_ch_no;
    }
}
</script>
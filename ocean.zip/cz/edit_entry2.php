<?php
include("session.php"); 

$active = 6;
include("db.php");
if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

$Sequence_no = $_GET['Sequence_no'];

// Prepare the SQL query with explicit table references for Sequence_no
$sql = "SELECT dc.`Sequence_no`, dc.`salesman`, dc.`driver`, dc.`1l`, dc.`500ml`, dc.`250ml`, dc.`2l`, dc.`coldd`, dc.`challan_no`, dc.`gadi_no`, dc.`gadi_route`, dc.`d_cash`, dc.`d_online`, dc.`udari`, dc.`Name`, dc.`date`, dc.`type`,  
        de.`gadi_exp`, de.`diesel`, de.`toll`, de.`s_man`, de.`chai_pani`, de.`other_exp` 
        FROM `daily_challan` dc 
        LEFT JOIN `daily_exp` de 
        ON dc.`Sequence_no` = de.`Sequence_no` 
        AND dc.challan_no = de.challan_no 
        AND dc.gadi_no = de.gadi_no 
        WHERE dc.`Sequence_no` = '$Sequence_no'"; // Fixed the table reference
                    
// Execute the query
$query = mysqli_query($conn, $sql);

// Check for query execution errors
if (!$query) {
    die("Database query failed: " . mysqli_error($conn));
}

// Fetch the result
$data = mysqli_fetch_assoc($query);

// If no data is found, you might want to handle this case
if (!$data) {
    echo "No data found for the given query.";
    exit;
}

$Sequence_no = $data['Sequence_no'];
$salesman = $data['salesman'];
$driver = $data['driver'];
$gadi_no = $data['gadi_no'];
$gadi_route = $data['gadi_route'];
$gadi_exp = $data['gadi_exp'];
$diesel = $data['diesel'];
$toll = $data['toll'];
$s_man = $data['s_man'];
$chai_pani = $data['chai_pani'];
$other_exp = $data['other_exp'];

$one_liter = $data['1l'];
$half_liter = $data['500ml'];
$quarter_liter = $data['250ml'];
$two_liter = $data['2l'];
$cold_drink = $data['coldd'];
$challan_no = $data['challan_no'];
$name = $data['Name'];
$d_cash = $data['d_cash'];
$d_online = $data['d_online'];
$udhari = $data['udari'];
$date = $data['date'];
$type = $data['type'];

?>

<div class="container">

<div class="col-lg-9 my-4">
        <form autocomplete="off" method="get" action="challanentry1.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Enter Challan Details : </h6>
                </div>
                <div class="card-body p-3 d-flex justify-content-evenly gap-3 align-items-start">
                <div style="width: 18rem;">
                    <strong>GADI DETAILS :</strong>
                    <div class="form-group">
                        <label for="gadiNo" style="margin-bottom: 8px;">Gadi no. :</label>
                        <input list="gadino" name="gadi_no" id="gadiNo" class="form-control"
                            value="<?php echo htmlspecialchars($gadi_no); ?>" required>
                        <datalist id="gadino">
                            <?php 
                            $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
                            $query = mysqli_query($conn, $sql);
                            while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                            <option value="<?php echo htmlspecialchars($row['gadi_no']); ?>" class="form-select">
                            </option>
                            <?php
                            }
                            ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <label for="gadir" style="margin-bottom: 8px;">Gadi Route :</label>
                        <input type="text" name="gadi_route" class="form-control" id="gadir"
                            value="<?php echo htmlspecialchars($gadi_route); ?>" >
                    </div>
                <?php if(htmlspecialchars($type) == "company"){ ?>

                    <div class="form-group">
                        <label for="gadiExp" style="margin-bottom: 8px;">Gadi Exp. :</label>
                        <input type="number" name="gadi_exp" class="form-control" id="gadiExp"
                            value="<?php echo htmlspecialchars($gadi_exp); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="diesel" style="margin-bottom: 8px;">Diesel :</label>
                        <input type="number" name="diesel" class="form-control" id="diesel"
                            value="<?php echo htmlspecialchars($diesel); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="toll" style="margin-bottom: 8px;">Toll :</label>
                        <input type="number" name="toll" class="form-control" id="toll"
                            value="<?php echo htmlspecialchars($toll); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="sMan" style="margin-bottom: 8px;">Salesman :</label>
                        <input type="number" name="s_man" class="form-control" id="sMan"
                            value="<?php echo htmlspecialchars($s_man); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="chaiPani" style="margin-bottom: 8px;">Chai Pani :</label>
                        <input type="number" name="chai_pani" class="form-control" id="chaiPani"
                            value="<?php echo htmlspecialchars($chai_pani); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="otherExp" style="margin-bottom: 8px;">Other Exp. :</label>
                        <input type="number" name="other_exp" class="form-control" id="otherExp"
                            value="<?php echo htmlspecialchars($other_exp); ?>" required>
                    </div>
                    <div class="form-group">
                            <label for="driverName" style="margin-bottom: 8px;">Driver Name :</label>
                            <select class="form-select" name="driver_name" id="driverName"
                                aria-label="Default select example" required>
                                <option value="NA"></option>
                                <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'company';";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                <option <?php echo ($row['name'] == $driver)? "selected" : ""; ?>
                                    value="<?php echo $row['name']; ?>" class="form-select">
                                    <?php echo $row['name']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>

                    <?php }?>

                        <div class="form-group">
                            <label for="salesmanName" style="margin-bottom: 8px;">Salesman Name :</label>
                            <select class="form-select" name="salesman_name" id="salesmanName"
                                aria-label="Default select example" required>
                                <option value="NA"></option>
                                <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                <option <?php echo ($row['name'] == $salesman)? "selected" : ""; ?>
                                    value="<?php echo $row['name']; ?>" class="form-select">
                                    <?php echo $row['name']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                    <div class="form-group">
                        <label for="gadiDate" style="margin-bottom: 8px;">Date :</label>
                        <input type="date" name="date" value="<?php echo htmlspecialchars($date); ?>"
                        format="DD-MMMM-YYYY"  class="form-control" id="date-picker" min="2014-01-01" max="" required>
                    </div>
                    <div class="form-group">
                        <label for="challan_no" style="margin-bottom: 8px;"> Challan no:</label>
                        <input type="text" name="challan_no" class="form-control" id="challan_no"
                            value="<?php echo htmlspecialchars($challan_no); ?>" required>
                        </div>
                        <input type="hidden" name="type" class="form-control" id="type"
                            value="<?php echo htmlspecialchars($type); ?>" required>
                </div>
                <div style="width: 18rem;">
                    <strong>DETAILS:</strong>
                    <div class="form-group">
                        <label for="oneLiter" style="margin-bottom: 8px;">1 liter:</label>
                        <input type="number" name="one_liter" class="form-control" id="oneLiter"
                            value="<?php echo htmlspecialchars($one_liter); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="halfLiter" style="margin-bottom: 8px;">500 ml:</label>
                        <input type="number" name="half_liter" class="form-control" id="halfLiter"
                            value="<?php echo htmlspecialchars($half_liter); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="quarterLiter" style="margin-bottom: 8px;">250 ml:</label>
                        <input type="number" name="quarter_liter" class="form-control" id="quarterLiter"
                            value="<?php echo htmlspecialchars($quarter_liter); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="twoLiter" style="margin-bottom: 8px;">2 liter:</label>
                        <input type="number" name="two_liter" class="form-control" id="twoLiter"
                            value="<?php echo htmlspecialchars($two_liter); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="coldDrink" style="margin-bottom: 8px;">Cold Drink:</label>
                        <input type="number" name="cold_drink" class="form-control" id="coldDrink"
                            value="<?php echo htmlspecialchars($cold_drink); ?>" required>
                    </div>
                    <strong style="margin-top: 2rem; margin-bottom: 0.9rem;">COLLECTION:</strong>
                    <div class="form-group">
                        <label for="case" style="margin-bottom: 8px;">Case:</label>
                        <input type="number" name="case" class="form-control" id="case"
                            value="<?php echo htmlspecialchars($d_cash); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="account" style="margin-bottom: 8px;">A/c me:</label>
                        <input type="number" name="account" class="form-control" id="account"
                            value="<?php echo htmlspecialchars($d_online); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="udhari" style="margin-bottom: 8px;">Udhari:</label>
                        <input type="number" name="udhari" class="form-control" id="udhari"
                            value="<?php echo htmlspecialchars($udhari); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="gadiName" style="margin-bottom: 8px;">Name :</label>
                        <input type="number" name="name" class="form-control" id="gadiName"
                            value="<?php echo htmlspecialchars($name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="Sequence_no" style="margin-bottom: 8px;">Sequence  No. :</label>
                        <input type="number" name="Sequence_no" class="form-control" id="Sequence_no"
                            value="<?php echo htmlspecialchars($Sequence_no); ?>" readonly required>
                    </div>
                </div>
                    
                </div>
                <div style="display: flex; justify-content: center;" class="row-1 d-flex mb-4 ">
                    <button type="submit" class="btn btn-primary w-50">Submit</button>
                </div>
            </div>
        </form>
    </div>

</div>
<?php
include("footer.php");
?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
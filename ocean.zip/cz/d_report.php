<?php
include("session.php"); 

$active = 9;

if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

?>

<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Daily Report</li>
    </ol>
</div>


<div class="row m-4 d-flex justify-content-center align-items-center">

    <div class="col-lg-7 my-4">
        <form autocomplete="off" method="get" action="d_report1.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0"> Enter details : </h6>
                </div>
                <div class="card-body p-3 d-flex flex-column justify-content-evenly gap-3 align-items-center">

                    <div class="w-40" style="display: flex;justify-content: space-around;">
                        <div class="form-group w-100  mt-3" style="display: flex; justify-content: space-evenly;">
                            <button type="button" class="btn btn-success" onclick="btn2()"
                                style="width: 49%;">Day</button>
                            <button type="button" class="btn btn-success" onclick="btn1()" style="width: 49%;">Range
                            </button>
                        </div>
                    </div>
                    
                    <div id="stu1" class="w-40" style="display: none;">
                        <label style="margin-bottom: 8px;">Select date range : </label>
                        <div class="form-group ">
                            <label for="exampleFormControlInput1" style="margin-bottom: 8px;">From : </label>
                            <input type="date" name="from" class="form-control" id="f_date">
                        </div>
                        <div class="form-group ">
                            <label for="exampleFormControlInput1" style="margin-bottom: 8px;">To : </label>
                            <input type="date" name="to" class="form-control" id="t_date">
                        </div>
                    </div>
                    <div id="sta1" class="w-40" style="display: block;">
                        <div class="form-group ">
                            <label for="exampleFormControlInput1" style="margin-bottom: 8px;">Select Date : </label>
                            <input type="date" name="date" class="form-control" id="d_date">
                        </div>
                    </div>


                </div>
                <div style="display: flex; justify-content: center;" class="row-1 d-flex mb-4 ">
                    <button type="submit" class="btn btn-primary w-30">Submit</button>
                </div>
            </div>
        </form>
    </div>

</div>




<?php
include("footer.php");
?>
<script>
    
function resetSelectElement(selectElement) {
    selectElement.value = '';
}

function btn2() {

    const form = document.getElementById('sta1');
    const form1 = document.getElementById('stu1');

    if (form.style.display === 'none' && form1.style.display === 'block') {
        const f_date = document.getElementById('f_date');
        const t_date = document.getElementById('t_date');
        form.style.display = 'block';
        form1.style.display = 'none';
        resetSelectElement(f_date);
        resetSelectElement(t_date);
    }
};


function btn1() {
    const form = document.getElementById('sta1');
    const form1 = document.getElementById('stu1');

    if (form.style.display === 'block' && form1.style.display === 'none') {
        const d_date = document.getElementById('d_date');
        form.style.display = 'none';
        form1.style.display = 'block';
        resetSelectElement(d_date);
    }
};
</script>
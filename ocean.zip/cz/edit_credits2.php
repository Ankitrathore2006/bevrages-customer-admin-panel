<?php
include("session.php"); 

$active = 13;
include("db.php");
if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

$id = $_GET['id'];

// Prepare the SQL query with explicit table references for Sequence_no
$sql = "SELECT `Sequence_no`, `emp_name`, `gadi_no`, `challan_no`, `mt`, `et`, `wate`, `new_party`, `total_box`, `trip1/2`, `b/c`, `dress`, `max_profit`, `max_average`, `role`, `date` FROM `daily_credit` WHERE `id` = '$id'"; // Fixed the table reference
                    
// Execute the query
$query = mysqli_query($conn, $sql);

// Check for query execution errors
if (!$query) {
    die("Database query failed: " . mysqli_error($conn));
}

// Fetch the result
$row = mysqli_fetch_assoc($query);

// If no data is found, you might want to handle this case
if (!$row) {
    echo "No data found for the given query.";
    exit;
}

$Sequence_no = $row['Sequence_no'];
$emp_name = $row['emp_name'];
$gadi_no = $row['gadi_no'];
$challan_no = $row['challan_no'];
$mt = $row['mt'];
$et = $row['et'];
$wate = $row['wate'];
$new_party = $row['new_party'];
$total_box = $row['total_box'];
$trip = $row['trip1/2'];
$b_c = $row['b/c'];
$dress = $row['dress'];
$max_profit = $row['max_profit'];
$max_average = $row['max_average'];
$role = $row['role'];
$date = $row['date'];


?>

<div class="container">

    <div class="col-lg-9 my-4">
        <form autocomplete="off" method="get" action="creditentry1.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Enter Employee Creadits : </h6>
                </div>
                <div class="card-body p-3 d-flex justify-content-evenly gap-3 align-items-start">

                    <div
                        style="display: flex;width: 90%;flex-direction: row;flex-wrap: wrap;justify-content: space-evenly;">

                        <div style="width: 14rem;" class="form-group">
                            <label for="Sequence_no" style="margin-bottom: 8px;">Sequence no. :</label>
                            <input type="number" name="Sequence_no" class="form-control" id="Sequence_no"
                                value="<?php echo $Sequence_no; ?>" required>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>" required>

                        <div style="width: 14rem;" class="form-group">
                            <label for="challan_no" style="margin-bottom: 8px;">Challan no:</label>
                            <input type="text" name="challan_no" value="<?php echo $challan_no; ?>" class="form-control"
                                id="challan_no" required>
                        </div>


                        <div style="width: 14rem;" class="form-group">
                            <label for="salesmanName" style="margin-bottom: 8px;">Employee Name :</label>
                            <select class="form-select" name="salesman_name" id="salesmanName"
                                aria-label="Default select example" required>
                                <option value="NA"></option>
                                <?php 
                                    $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'company';";
                                    $query = mysqli_query($conn,$sql);
                                    while($row = mysqli_fetch_assoc($query)){
                                    ?>
                                <option <?php echo ($row['name'] == $emp_name)? "selected" : ""; ?>
                                    value="<?php echo $row['name']; ?>" class="form-select">
                                    <?php echo $row['name']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="morningTimeSalesman" style="margin-bottom: 8px;">Morning Time :</label>
                            <input type="number" name="salesman_morning_time" class="form-control"
                                id="morningTimeSalesman" value="<?php echo $mt; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="eveningTimeSalesman" style="margin-bottom: 8px;">Evening Time :</label>
                            <input type="number" name="salesman_evening_time" class="form-control"
                                id="eveningTimeSalesman" value="<?php echo $et; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="wakeUpSalesman" style="margin-bottom: 8px;">Whatsup :</label>
                            <input type="number" name="salesman_wake_up" class="form-control" id="wakeUpSalesman"
                                value="<?php echo $wate; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="newPartySalesman" style="margin-bottom: 8px;">New Party :</label>
                            <input type="number" name="salesman_new_party" class="form-control" id="newPartySalesman"
                                value="<?php echo $new_party; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="totalBoxSalesman" style="margin-bottom: 8px;">Total box 200/250 :</label>
                            <input type="number" name="salesman_total_box" class="form-control" id="totalBoxSalesman"
                                value="<?php echo $total_box; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="tripSalesman" style="margin-bottom: 8px;">Trip 1/2 :</label>
                            <input type="number" name="salesman_trip" class="form-control" id="tripSalesman"
                                value="<?php echo $trip; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="bottleBoxCapSalesman" style="margin-bottom: 8px;">Bottle/box/cap :</label>
                            <input type="number" name="salesman_bottle_box_cap" class="form-control"
                                id="bottleBoxCapSalesman" value="<?php echo $b_c; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="dressSalesman" style="margin-bottom: 8px;">Dress :</label>
                            <input type="number" name="salesman_dress" class="form-control" id="dressSalesman"
                                value="<?php echo $dress; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="maxProfitSalesman" style="margin-bottom: 8px;">Max profit :</label>
                            <input type="number" name="salesman_max_profit" class="form-control" id="maxProfitSalesman"
                                value="<?php echo $max_profit; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="maxAveragePriceSalesman" style="margin-bottom: 8px;">Max average price :</label>
                            <input type="number" name="salesman_max_avg_price" class="form-control"
                                id="maxAveragePriceSalesman" value="<?php echo $max_average; ?>" required>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="gadiNo" style="margin-bottom: 8px;">Gadi no. :</label>
                            <select class="form-select" name="gadi_no" id="gadiNo" aria-label="Default select example"
                                required>
                                <option value="NA"></option>
                                <?php 
                                $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
                                $query = mysqli_query($conn,$sql);
                                $selectprint="";
                                
                                while($row = mysqli_fetch_assoc($query)){
                                    
                                ?>
                                <option <?php echo ($row['gadi_no'] == $gadi_no)? "selected" : ""; ?>
                                    <?php echo $row['gadi_no']; ?> value="<?php echo $row['gadi_no']; ?>"
                                    class="form-select">

                                    <?php echo $row['gadi_no']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                        <div style="width: 14rem;" class="form-group">
                            <label for="gadiDate" style="margin-bottom: 8px;">Date :</label>
                            <input type="date" value="<?php echo $date; ?>" name="gadi_date" class="form-control"
                                id="date-picker" min="2014-01-01" max="" required>
                        </div>
                    </div>

                </div>
                <div style="display: flex; justify-content: center;" class="row-1 d-flex mb-4 ">
                    <button type="submit" class="btn btn-primary w-50">Submit</button>
                </div>
            </div>
        </form>
    </div>

</div>
<?php
include("footer.php");
?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
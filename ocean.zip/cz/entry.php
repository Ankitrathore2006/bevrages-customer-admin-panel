<?php
include("session.php"); 

$active =5;
include("db.php");

if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

?>


<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Challan Entry</li>
    </ol>
</div>


<div class="row m-4 d-flex justify-content-center align-items-center">

    <div class="col-lg-9 my-4">
        <form autocomplete="off" method="get" action="challanentry.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Enter Challan Details : </h6>
                </div>
                <div class="card-body p-3 d-flex justify-content-evenly gap-3 align-items-start">

                    <div style="width: 18rem;" class="">
                        <strong>GADI DETAILS :</strong>

                        <div style="display: flex;justify-content: space-around;">
                            <div class="form-group w-100  mt-3" style="display: flex; justify-content: space-evenly;">
                                <button type="button" class="btn btn-success" onclick="btn2()"
                                    style="width: 49%;">Company</button>
                                <button type="button" class="btn btn-success" onclick="btn1()" style="width: 49%;">Self
                                </button>
                            </div>
                        </div>

                        <div id="stu1" style="margin-top: 0rem; display: none;">
                            <div class="form-group">
                                <label for="employee_name" style="margin-bottom: 8px;">Employee Name :</label>
                                <select class="form-select" name="employee_name" id="employee_name"
                                    aria-label="Default select example" required>
                                    <option value="NA"></option>
                                    <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'self';";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                    <option value="<?php echo $row['name']; ?>" class="form-select">
                                        <?php echo $row['name']; ?>
                                    </option>
                                    <?php  }?>
                                </select>
                            </div>
                        </div>
                        <div id="sta1" style="margin-top: 0rem; display: block;">
                            <div class="form-group">
                                <label for="driverName" style="margin-bottom: 8px;">Driver Name :</label>
                                <select class="form-select" name="driver_name" id="driverName"
                                    aria-label="Default select example" required>
                                    <option value="NA"></option>
                                    <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'company'";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                    <option value="<?php echo $row['name']; ?>" class="form-select">
                                        <?php echo $row['name']; ?>
                                    </option>
                                    <?php  }?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="salesmanName" style="margin-bottom: 8px;">Salesman Name :</label>
                                <select class="form-select" name="salesman_name" id="salesmanName"
                                    aria-label="Default select example" required>
                                    <option value="NA"></option>
                                    <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'company';";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                    <option value="<?php echo $row['name']; ?>" class="form-select">
                                        <?php echo $row['name']; ?>
                                    </option>
                                    <?php  }?>
                                </select>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label for="gadiNo" style="margin-bottom: 8px;">Gadi no. :</label>
                            <select class="form-select" name="gadi_no" id="gadiNo" aria-label="Default select example"
                                required>
                                <option value="NA"></option>
                                <?php 
                                $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
                                $query = mysqli_query($conn,$sql);
                                while($row = mysqli_fetch_assoc($query)){
                                ?>
                                <option value="<?php echo $row['gadi_no']; ?>" class="form-select">

                                    <?php echo $row['gadi_no']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                        
                            <div class="form-group">
                                <label for="gadir" style="margin-bottom: 8px;">Gadi Route :</label>
                                <input type="text" name="gadi_route" class="form-control" id="gadir" required>
                            </div>
                        <div id="extra">
                            <div class="form-group">
                                <label for="gadiExp" style="margin-bottom: 8px;">Gadi Exp. :</label>
                                <input type="number" value="1000" name="gadi_exp" class="form-control" id="gadiExp"
                                    >
                            </div>
                            <div class="form-group">
                                <label for="diesel" style="margin-bottom: 8px;">Diesel :</label>
                                <input type="number" name="diesel" class="form-control" id="diesel" >
                            </div>
                            <div class="form-group">
                                <label for="toll" style="margin-bottom: 8px;">Toll :</label>
                                <input type="number" name="toll" class="form-control" id="toll" >
                            </div>
                            <div class="form-group">
                                <label for="sMan" style="margin-bottom: 8px;">Salesman :</label>
                                <input type="number" value="350" name="s_man" class="form-control" id="sMan" >
                            </div>
                            <div class="form-group">
                                <label for="chaiPani" style="margin-bottom: 8px;">Chai Pani :</label>
                                <input type="number" value="0" name="chai_pani" class="form-control" id="chaiPani" >
                            </div>
                            <div class="form-group">
                                <label for="otherExp" style="margin-bottom: 8px;">Other Exp. :</label>
                                <input type="number" value="0" name="other_exp" class="form-control" id="otherExp" >
                            </div>

                        </div>
                        <div class="form-group">
                            <label for="challan_no" style="margin-bottom: 8px;"> Challan no:</label>
                            <?php 
                            $sql = "SELECT MAX(`challan_no`) as max_ch_no FROM `daily_challan`;";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                            <input type="text" name="challan_no" value="<?php echo $row['max_ch_no']+1; ?>"
                                class="form-control" id="challan_no" required>
                            <?php  }?>
                        </div>
                        <div class="form-group">
                            <label for="Sequence_no" style="margin-bottom: 8px;"> Sequence no. :</label>
                            <?php 
                            $sql = "SELECT MAX(`Sequence_no`) as max_ch_no FROM `daily_challan`;";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                            <input type="number" name="Sequence_no" class="form-control" id="Sequence_no"
                                value="<?php echo $row['max_ch_no']+1; ?>" readonly required>

                            <?php  }?>
                        </div>

                    </div>

                    <div style=" width: 18rem;">
                        <strong>DETAILS:</strong>
                        <div class="form-group">
                            <label for="oneLiter" style="margin-bottom: 8px;">1 liter:</label>
                            <input type="number" name="one_liter" class="form-control" id="oneLiter" required>
                        </div>
                        <div class="form-group">
                            <label for="halfLiter" style="margin-bottom: 8px;">500 ml:</label>
                            <input type="number" name="half_liter" class="form-control" id="halfLiter" required>
                        </div>
                        <div class="form-group">
                            <label for="quarterLiter" style="margin-bottom: 8px;">250 ml:</label>
                            <input type="number" name="quarter_liter" class="form-control" id="quarterLiter" required>
                        </div>
                        <div class="form-group">
                            <label for="twoLiter" style="margin-bottom: 8px;">2 liter:</label>
                            <input type="number" name="two_liter" class="form-control" id="twoLiter" required>
                        </div>
                        <div class="form-group">
                            <label for="coldDrink" style="margin-bottom: 8px;">Cold Drink:</label>
                            <input type="number" value="0" name="cold_drink"  class="form-control" id="coldDrink" required>
                        </div>
                        <div class="form-group" style="margin: 19px 10px !important;">
                            <strong class="py-5">COLLECTION:</strong>
                        </div>

                        <div class="form-group">
                            <label for="case" style="margin-bottom: 8px;">Case:</label>
                            <input type="number" name="case" class="form-control" id="case" required>
                        </div>
                        <div class="form-group">
                            <label for="account" style="margin-bottom: 8px;">A/c me:</label>
                            <input type="number" name="account" class="form-control" id="account" required>
                        </div>
                        <div class="form-group">
                            <label for="udhari" style="margin-bottom: 8px;">Udhari:</label>
                            <input type="number" value="0" name="udhari" class="form-control" id="udhari" required>
                        </div>
                        <div class="form-group">
                            <label for="gadiName" style="margin-bottom: 8px;">Na - Me :</label>
                            <input type="number" value="0" name="name" class="form-control" id="gadiName" required>
                        </div>

                        <div class="form-group">
                            <label for="gadiDate" style="margin-bottom: 8px;">Date :</label>
                            <input type="date" name="gadi_date" class="form-control" id="date-picker" min="2014-01-01"
                                max="" required>
                        </div>


                    </div>
                </div>
                <div style="display: flex; justify-content: center;" class="row-1 d-flex mb-4 ">
                    <button type="submit" class="btn btn-primary w-50">Submit</button>
                </div>
            </div>
        </form>
    </div>

</div>

<?php
        include("footer.php");
        ?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
<script>
const employeeName = document.getElementById('employee_name');
const challanNo = document.getElementById('challan_no');
// const gadi_no = document.getElementById('gadi_no');
const pr_ch_no = challanNo.value;

employeeName.addEventListener('change', function() {
    if (employeeName.value === 'plant sale') {
        challanNo.value = 0;

    } else {
        challanNo.value = pr_ch_no;
    }
});


function resetSelectElement(selectElement) {
    selectElement.selectedIndex = 0;
}

function btn2() {
    const form = document.getElementById('sta1');
    const form1 = document.getElementById('stu1');
    const extra = document.getElementById('extra');

    if (form.style.display === 'none' && form1.style.display === 'block') {
        const employeeName = document.getElementById('employee_name');
        form.style.display = 'block';
        extra.style.display = 'block';
        form1.style.display = 'none';
        resetSelectElement(employeeName);
        challanNo.value = pr_ch_no;
    }
}

function btn1() {
    const form = document.getElementById('sta1');
    const form1 = document.getElementById('stu1');

    if (form.style.display === 'block' && form1.style.display === 'none') {
        const driverName = document.getElementById('driverName');
        const salesmanName = document.getElementById('salesmanName');
        form.style.display = 'none';
        extra.style.display = 'none';
        form1.style.display = 'block';
        resetSelectElement(driverName);
        resetSelectElement(salesmanName);
        challanNo.value = pr_ch_no;
    }
}
</script>
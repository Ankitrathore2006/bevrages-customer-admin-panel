<?php
include("session.php"); 

include("db.php");

// Ensure the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {


    $salesman_name = mysqli_real_escape_string($conn, $_GET['salesman_name']);
    $salesman_morning_time = mysqli_real_escape_string($conn, $_GET['salesman_morning_time']);
    $salesman_evening_time = mysqli_real_escape_string($conn, $_GET['salesman_evening_time']);
    $salesman_wake_up = mysqli_real_escape_string($conn, $_GET['salesman_wake_up']);
    $salesman_new_party = mysqli_real_escape_string($conn, $_GET['salesman_new_party']);
    $salesman_total_box = mysqli_real_escape_string($conn, $_GET['salesman_total_box']);
    $salesman_trip = mysqli_real_escape_string($conn, $_GET['salesman_trip']);
    $salesman_bottle_box_cap = mysqli_real_escape_string($conn, $_GET['salesman_bottle_box_cap']);
    $salesman_dress = mysqli_real_escape_string($conn, $_GET['salesman_dress']);
    $salesman_max_profit = mysqli_real_escape_string($conn, $_GET['salesman_max_profit']);
    $salesman_max_avg_price = mysqli_real_escape_string($conn, $_GET['salesman_max_avg_price']);

    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $gadi_no = mysqli_real_escape_string($conn, $_GET['gadi_no']);
    $gadi_date = mysqli_real_escape_string($conn, $_GET['gadi_date']);
    $challan_no = mysqli_real_escape_string($conn, $_GET['challan_no']);
    $sequence_no = mysqli_real_escape_string($conn, $_GET['Sequence_no']);

  

    // Insert salesman data into `daily_credit` table
    $sql_salesman = "UPDATE `daily_credit` 
    SET `emp_name` = '$salesman_name',
        `gadi_no` = '$gadi_no',
        `challan_no` = '$challan_no',
        `mt` = '$salesman_morning_time',
        `et` = '$salesman_evening_time',
        `wate` = '$salesman_wake_up',
        `new_party` = '$salesman_new_party',
        `total_box` = '$salesman_total_box',
        `trip1/2` = '$salesman_trip',
        `b/c` = '$salesman_bottle_box_cap',
        `dress` = '$salesman_dress',
        `max_profit` = '$salesman_max_profit',
        `max_average` = '$salesman_max_avg_price',
        `date` = '$gadi_date'
    WHERE `id` = '$id'";

$result_salesman = mysqli_query($conn, $sql_salesman);


    // Validate results and provide feedback
    if ($result_salesman) {
        echo "<script>
                alert('Successfully updated !');
                window.location.href='edit_credits.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
    }
}
?>

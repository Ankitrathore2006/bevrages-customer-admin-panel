<?php
$active = 3;
include("session.php"); 

include("db.php");

if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }
?>

<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Add Employee</li>
    </ol>
</div>


<div class="row m-4">

    <div class="col-lg-4 mb-2">
        <form autocomplete="off" method="get" action="add_emp1.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Enter Employee Details : </h6>
                </div>
                <div class="card-body p-3 d-flex justify-content-center align-items-center">
                    <ul class="list-group">
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">Employee Name :</h6>
                                    <input type="text" name="employee_name" id="employeeName" class="form-control"
                                        required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">Mobile no :</h6>
                                    <input type="tel" name="mobile_no" class="form-control" required pattern="[0-9]{10}" title="Enter a valid 10-digit mobile number" id="challan_no" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">Joining Date :</h6>
                                    <input type="date" name="j_date" class="form-control" id="date" required=""
                                        onfocus="focused(this)" onfocusout="defocused(this)" style="width: 123%;">
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">Adhar Card no. :</h6>
                                    <input type="number" name="adhar" class="form-control" id="oneLiter" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm"> Address :</h6>
                                    <input type="text" name="address" class="form-control" id="halfLiter" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column ">
                                    <h6 class="mb-1 text-dark text-sm"> Type :</h6>
                                    <select class="form-select" name="type"style="width: 12rem;" aria-label="Default select example">
                                        <option value="Na"></option>
                                        <option value="self">Self</option>
                                        <option value="company">Company</option>
                                    </select>
                                </div>
                            </div>

                        </li>

                        <div style="display: flex; justify-content: center;" class="row-1 d-flex mt-4">
                            <button type="submit" class="btn btn-primary w-75">Submit</button>
                        </div>
                    </ul>

                </div>
            </div>
        </form>
    </div>




    <div class="col-lg-8 mb-lg-0 mb-4">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">Employees :</h6>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-items-center ">
                    <tbody>
                        <tr>
                            <td >
                                <div class="d-flex px-2 py-1 align-items-center">
                                    <div class="ms-4">
                                        <p class="text-xs font-weight-bold mb-0">Name :</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Phone :</p>
                                </div>
                            </td>
                            <td class="w-30">
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Adhar :</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Address :</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Joining Date :</p>
                                </div>
                            </td>
                            
                        </tr>

                        <?php 
                    $sql = "SELECT * FROM `employee`;";
                    $query = mysqli_query($conn,$sql);
                    while($row = mysqli_fetch_assoc($query)){
                ?>


                        <tr>
                            <td >
                                <div class="d-flex px-2 py-1 align-items-center">
                                    <div class="ms-4">
                                        <h6 class="text-sm mb-0"><?php echo $row['name']; ?></h6>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['mobile']; ?></h6>
                                </div>
                            </td>
                            <td class="w-30">
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['adhar']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['address']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php $date = $row['joining_date']; echo date("d-m-Y", strtotime($date));  ?></h6>
                                </div>
                            </td>
                            
                        </tr>
                        <?php  }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



</div>

<?php
include("footer.php");
?>
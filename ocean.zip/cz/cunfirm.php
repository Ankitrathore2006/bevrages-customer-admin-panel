<?php
include("session.php"); 

if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect URL parameters
    $id = $_GET['id'];
    $str = $_GET['str'];
?>

<div class="row m-5 justify-content-center">

    <div class="col-lg-5">
        <div class="card align-items-evenly">
            <div class="card-header pb-0 p-3">
                <h6 class="mb-0">Please Cunfirm : </h6>
            </div>
            <div class="card-body p-3 px-4">
                <ul class="list-group">
                    <li class="list-group-item border-0 d-flex flex-column gap-3 justify-content-between ps-0 mb-2 border-radius-lg">
                        <div class="modal-body">
                            <strong class="text-warning">warning!</strong> Please press ok if you want delete the
                            <?php echo $str; ?> .
                        </div>
                        <div style="display: flex; justify-content: center; gap: 2rem;" class="row-1 d-flex ">
                        <a href="<?php echo ($str == "employee") ? "add_emp.php" : "add_gadi.php"; ?>"> <button type="button" class="btn btn-secondary">Cancel</button></a>
                            <a href="delete_entry.php?id=<?php echo $id; ?>&str=<?php echo $str; ?>"><button type="button"
                                    class="btn btn-danger">Delete</button></a>
                        </div>
                    </li>


                </ul>
            </div>
        </div>
    </div>
</div>


<?php
}
include("footer.php");
?>
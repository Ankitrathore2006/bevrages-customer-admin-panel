<?php
//Start session
session_start();
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || !isset($_SESSION['type']) || (trim($_SESSION['id']) == '') || (trim($_SESSION['type']) == '')) 
{
    header("location: sign-in.php");
    exit();
}
$session_id=$_SESSION['id'];
$session_id=$_SESSION['type'];
?>

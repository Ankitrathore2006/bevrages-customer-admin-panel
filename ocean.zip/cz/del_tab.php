<?php
include("session.php"); 

$active = 11;
include("db.php");
if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }

// Get 'gadi_no' and 'date' from query parameters
$gadi_no = $_GET['gadi_no'];
$date = $_GET['date'];
$month = substr($date,5,2);

 
?>

<div class="container">
    
    <div style="margin-left: 83px;margin-top: 40px;color: #808091;" class=1 d-flex ">
        <h4><strong> Delete the data </strong></h4>
    </div>
    <div style=" display: flex;  margin-top: 2.5rem;">
        <div style="margin: 1rem">
        <table id="example" class="table table-bordered table-striped">
            <thead>
                    <th>Action</th>
                    <th>Date</th>
                    <th>challan no</th>
                    <th>gadi no</th>
                    <th>one liter</th>
                    <th>half liter</th>
                    <th>quarter liter</th>
                    <th>two liter</th>
                    <th>cold drink</th>

                    <th>name</th>
                    <th>Deposit cash</th>
                    <th>Deposit online</th>
                    <th>udhari</th>

                    <th>gadi route</th>
                    <th>gadi exp</th>
                    <th>diesel</th>
                    <th>toll</th>
                    <th>Salesman salary</th>
                    <th>chai pani</th>
                    <th>other exp</th>

                    <th>Driver name</th>
                    <th>Driver morning time</th>
                    <th>Driver evening time</th>
                    <th>Driver Whatsup</th>
                    <th>Driver new party</th>
                    <th>Driver total box</th>
                    <th>Driver trip</th>
                    <th>Driver bottle box cap</th>
                    <th>Driver dress</th>
                    <th>Driver max profit</th>
                    <th>Driver max avg price</th>

                    <th>Salesman name</th>
                    <th>Salesman morning time</th>
                    <th>Salesman evening time</th>
                    <th>Salesman Whatsup</th>
                    <th>Salesman new party</th>
                    <th>Salesman total box</th>
                    <th>Salesman trip</th>
                    <th>Salesman bottle box cap</th>
                    <th>Salesman dress</th>
                    <th>Salesman max profit</th>
                    <th>Salesman max avg price</th>


            </thead>
            <?php
            // Prepare the SQL query
                $sql = "SELECT dc.id as daily_challan_id, de.id as daily_exp_id, dc_credit.id as daily_credit_id, dc.*, de.*, dc_credit.*  FROM 
                        daily_challan dc
                        INNER JOIN daily_exp de ON dc.challan_no = de.challan_no AND dc.date = de.date
                        INNER JOIN daily_credit dc_credit ON dc.challan_no = dc_credit.challan_no AND dc.date = dc_credit.date
                        WHERE dc.gadi_no = '$gadi_no' AND month(dc.date)='$month'";

                // Execute the query
                $query = mysqli_query($conn,$sql);
                    while($data = mysqli_fetch_assoc($query)){


                // Extract values for use in the form
                $driver_name = $data['driver_name'];
                $driver_morning_time = $data['mt'];
                $driver_evening_time = $data['et'];
                $driver_wake_up = $data['wate'];
                $driver_new_party = $data['new_party'];
                $driver_total_box = $data['total_box'];
                $driver_trip = $data['trip1/2'];
                $driver_bottle_box_cap = $data['b/c'];
                $driver_dress = $data['dress'];
                $driver_max_profit = $data['max_profit'];
                $driver_max_avg_price = $data['max_average'];

                $salesman_name = $data['salesman'];
                $salesman_morning_time = $data['mt']; // Adjust as needed
                $salesman_evening_time = $data['et']; // Adjust as needed
                $salesman_wake_up = $data['wate']; // Adjust as needed
                $salesman_new_party = $data['new_party']; // Adjust as needed
                $salesman_total_box = $data['total_box']; // Adjust as needed
                $salesman_trip = $data['trip1/2']; // Adjust as needed
                $salesman_bottle_box_cap = $data['b/c']; // Adjust as needed
                $salesman_dress = $data['dress']; // Adjust as needed
                $salesman_max_profit = $data['max_profit']; // Adjust as needed
                $salesman_max_avg_price = $data['max_average']; // Adjust as needed

                $date = $data['date'];
                $gadi_no = $data['gadi_no'];
                $gadi_route = $data['gadi_route'];
                $gadi_exp = $data['gadi_exp'];
                $diesel = $data['diesel'];
                $toll = $data['toll'];
                $s_man = $data['s_man'];
                $chai_pani = $data['chai_pani'];
                $other_exp = $data['other_exp'];

                $one_liter = $data['1l'];
                $half_liter = $data['500ml'];
                $quarter_liter = $data['250ml'];
                $two_liter = $data['2l'];
                $cold_drink = $data['coldd'];

                $challan_no = $data['challan_no'];
                $name = $data['Name'];
                $d_cash = $data['d_cash'];
                $d_online = $data['d_online'];

                $udhari = $data['udari'];   
                $daily_challan_id = $data['daily_challan_id'];   
                $daily_credit_id = $data['daily_credit_id'];   
                $daily_exp_id = $data['daily_exp_id'];  
                ?>
            <tbody>
                    <td><a href="delen.php?daily_challan_id=<?php echo htmlspecialchars($daily_challan_id); ?>&daily_credit_id=<?php echo htmlspecialchars($daily_credit_id); ?>&daily_exp_id=<?php echo htmlspecialchars($daily_exp_id); ?>&gadi_no=<?php echo $_GET['gadi_no'];?>&date=<?php echo $_GET['date'];?>"><button  type="button" class="btn btn-danger w-100">Delete</button></a></td>
                    <td><?php echo htmlspecialchars($date ); ?></td>
                    <td><?php echo htmlspecialchars($challan_no ); ?></td>
                    <td><?php echo htmlspecialchars($gadi_no ); ?></td>


                    <td><?php echo htmlspecialchars($one_liter ); ?></td>
                    <td><?php echo htmlspecialchars($half_liter ); ?></td>
                    <td><?php echo htmlspecialchars($quarter_liter ); ?></td>
                    <td><?php echo htmlspecialchars($two_liter ); ?></td>
                    <td><?php echo htmlspecialchars($cold_drink ); ?></td>

                    <td><?php echo htmlspecialchars($name ); ?></td>
                    <td><?php echo htmlspecialchars($d_cash ); ?></td>
                    <td><?php echo htmlspecialchars($d_online ); ?></td>
                    <td><?php echo htmlspecialchars($udhari ); ?></td>

                    <td><?php echo htmlspecialchars($gadi_route ); ?></td>
                    <td><?php echo htmlspecialchars($gadi_exp ); ?></td>
                    <td><?php echo htmlspecialchars($diesel ); ?></td>
                    <td><?php echo htmlspecialchars($toll ); ?></td>
                    <td><?php echo htmlspecialchars($s_man ); ?></td>
                    <td><?php echo htmlspecialchars($chai_pani ); ?></td>
                    <td><?php echo htmlspecialchars($other_exp ); ?></td>

                    <td><?php echo htmlspecialchars($driver_name ); ?></td>
                    <td><?php echo htmlspecialchars($driver_morning_time ); ?></td>
                    <td><?php echo htmlspecialchars($driver_evening_time ); ?></td>
                    <td><?php echo htmlspecialchars($driver_wake_up ); ?></td>
                    <td><?php echo htmlspecialchars($driver_new_party ); ?></td>
                    <td><?php echo htmlspecialchars($driver_total_box ); ?></td>
                    <td><?php echo htmlspecialchars($driver_trip ); ?></td>
                    <td><?php echo htmlspecialchars($driver_bottle_box_cap ); ?></td>
                    <td><?php echo htmlspecialchars($driver_dress ); ?></td>
                    <td><?php echo htmlspecialchars($driver_max_profit ); ?></td>
                    <td><?php echo htmlspecialchars($driver_max_avg_price ); ?></td>

                    <td><?php echo htmlspecialchars($salesman_name ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_morning_time ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_evening_time ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_wake_up ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_new_party ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_total_box ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_trip ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_bottle_box_cap ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_dress ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_max_profit ); ?></td>
                    <td><?php echo htmlspecialchars($salesman_max_avg_price ); ?></td>
<?php
                    }
?>

            </tbody>
        </table>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
        <script src="//cdn.datatables.net/2.1.3/js/dataTables.min.js"></script>
        <script>

            
           $(document).ready( function () {
            var table = $('#example').DataTable( {
                paging: false
                
            });
            } );

        </script>
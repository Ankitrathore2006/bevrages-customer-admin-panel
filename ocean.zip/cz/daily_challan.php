<?php
include("session.php"); 

include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $gadi_no = $_GET['gadi_no'];
    $date = $_GET['date'];
    ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>oceangelide</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        .cat-1, .cat-2, .cat-3, .cat-4 {
            margin: 5px;
        }

        td {
            text-align: center;
        }

        .cont {
            display: flex;
            justify-content: space-between;
            margin-top: 8px;
        }
    </style>
</head>

<body>

    <header></header>
    <main style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
        <div id="printcontent">
        <!-- start -->
        <?php
        $query = "SELECT *  FROM `rate` WHERE `date` <= '$date' ORDER BY id DESC LIMIT 1;";
        $query_run = mysqli_query($conn, $query);
        if (mysqli_num_rows($query_run) > 0) {
            while ($row = mysqli_fetch_array($query_run)) {
                $r_onel = $row['1l'];
                $r_halfml = $row['500ml'];
                $r_quatml = $row['250ml'];
                $r_twol = $row['2l'];
                $r_coldd = $row['col'];

                $query = "SELECT * FROM daily_challan dc 
                          INNER JOIN daily_exp de ON dc.challan_no = de.challan_no AND dc.date = de.date 
                          WHERE de.date = '$date' AND de.gadi_no ='$gadi_no';";
                $query_run = mysqli_query($conn, $query);
                if (mysqli_num_rows($query_run) > 0) {
                    while ($row = mysqli_fetch_array($query_run)) {
                        $onel = $row['1l'];
                        $halfml = $row['500ml'];
                        $quatml = $row['250ml'];
                        $twol = $row['2l'];
                        $coldd = $row['coldd'];
                        $challan_no = $row['challan_no'];
                        $d_cash = $row['d_cash'];
                        $d_online = $row['d_online'];
                        $udari = $row['udari'];
                        $gadi_no = $row['gadi_no'];
                        $gadi_route = $row['gadi_route'];
                        $gadi_exp = $row['gadi_exp'];
                        $diesel = $row['diesel'];
                        $toll = $row['toll'];
                        $s_man = $row['s_man'];
                        $chai_pani = $row['chai_pani'];
                        $other_exp = $row['other_exp'];
                        $Name = $row['Name'];

                        $P_1l = $onel * $r_onel;
                        $P_500ml = $halfml * $r_halfml;
                        $P_250l = $quatml * $r_quatml;
                        $P_2l = $twol * $r_twol;
                        $P_col = $coldd * $r_coldd;

                        $total_exp = $gadi_exp + $diesel + $toll + $s_man + $chai_pani + $other_exp;
                        $total_kharcha = $P_1l + $P_250l + $P_500ml + $P_2l + $P_col + $total_exp;
                        $total_coll = $d_cash + $d_online + $udari + $Name;
                        $total = $total_coll - $total_kharcha;
                        ?>
                        <div style="margin: 1rem; border: 2px solid black; paddind: 2px;">
                            <span style="display: flex; justify-content: center; font-size: 1.5rem; padding: 10px 0px; font-weight: bolder; color: rgb(20, 20, 163);">
                                TRUPTI BEVERAGES 212/5,GRAM PALDA INDORE (M.P.)
                            </span>
                            <div style="display: flex; justify-content: space-around;" class="row-1 d-flex ">
                                <span><strong>Gadi Route : </strong> <?php echo $gadi_route; ?></span>
                                <span><strong>Gadi No. : </strong> <?php echo $gadi_no; ?></span>
                                <span><strong>Date : </strong> <?php $newDate = date("d-m-Y", strtotime($date));  echo $newDate; ?></span>
                                <span><strong>Challan No. : </strong> <?php echo $challan_no; ?></span>
                            </div>
                            <div class="cont">
                                <div class="cat-1">
                                    <table style="margin-bottom: 0;" class="table table-striped">
                                        <tr>
                                            <th>Box : </th>
                                            <th>Rate : </th>
                                            <th>Count : </th>
                                            <th>Total price : </th>
                                        </tr>
                                        <tr>
                                            <th>1 Liter</th>
                                            <td><?php echo $r_onel; ?></td>
                                            <td><?php echo $onel; ?></td>
                                            <th><?php echo $P_1l; ?></th>
                                        </tr>
                                        <tr>
                                            <th>500 Ml</th>
                                            <td><?php echo $r_halfml; ?></td>
                                            <td><?php echo $halfml; ?></td>
                                            <th><?php echo $P_500ml; ?></th>
                                        </tr>
                                        <tr>
                                            <th>250 Ml</th>
                                            <td><?php echo $r_quatml; ?></td>
                                            <td><?php echo $quatml; ?></td>
                                            <th><?php echo $P_250l; ?></th>
                                        </tr>
                                        <tr>
                                            <th>2 Liter</th>
                                            <td><?php echo $r_twol; ?></td>
                                            <td><?php echo $twol; ?></td>
                                            <th><?php echo $P_2l; ?></th>
                                        </tr>
                                        <tr>
                                            <th>Cold Drink</th>
                                            <td><?php echo $r_coldd; ?></td>
                                            <td><?php echo $coldd; ?></td>
                                            <th><?php echo $P_col; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Gadi Exp.</th>
                                            <th><?php echo $gadi_exp; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Diesel</th>
                                            <th><?php echo $diesel; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Toll</th>
                                            <th><?php echo $toll; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Sales Man</th>
                                            <th><?php echo $s_man; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Chai Pani</th>
                                            <th><?php echo $chai_pani; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Other Exp.</th>
                                            <th><?php echo $other_exp; ?></th>
                                        </tr>
                                        <tr>
                                            <th colspan="3"><strong>Total Exp. : </strong></th>
                                            <th><strong><?php echo $total_kharcha; ?></strong></th>
                                        </tr>
                                    </table>
                                </div>
                                <div class="cat-2">
                                    <table class="table table-striped">
                                        <tr>
                                            <strong>COLLECTION</strong>
                                        </tr>
                                        <tr>
                                            <th>Case : </th>
                                            <td><?php echo $d_cash; ?></td>
                                        </tr>
                                        <tr>
                                            <th>A/C me : </th>
                                            <td><?php echo $d_online; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Udari : </th>
                                            <td><?php echo $udari; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Name : </th>
                                            <td><?php echo $Name; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Total collection : </th>
                                            <th><?php echo $total_coll; ?></th>
                                        </tr>
                                    </table>
                                    <div style="text-align: center; font-weight: bolder; font-size: 25px; margin-top: 7rem;">
                                        <strong><?php echo ($total < 0) ? '<span class="text-danger">' . $total . ' LOSS</span>' : '<span class="text-success">' . $total . ' PROFIT</span>'; ?></strong>
                                    </div>
                                </div>
                                <?php
                                $query_credit = "SELECT * FROM daily_credit WHERE challan_no='$challan_no' AND date = '$date'";
                                $query_run_credit = mysqli_query($conn, $query_credit);
                                if (mysqli_num_rows($query_run_credit) > 0) {
                                    while ($row_credit = mysqli_fetch_array($query_run_credit)) {
                                        $emp_name = $row_credit['emp_name'];
                                        $mt = $row_credit['mt'];
                                        $et = $row_credit['et'];
                                        $wate = $row_credit['wate'];
                                        $new_party = $row_credit['new_party'];
                                        $total_box = $row_credit['total_box'];
                                        $trip1 = $row_credit['trip1/2'];
                                        $b = $row_credit['b/c'];
                                        $dress = $row_credit['dress'];
                                        $max_profit = $row_credit['max_profit'];
                                        $max_average = $row_credit['max_average'];
                                        $role = $row_credit['role'];
                                        $total_credit = $mt + $et + $wate + $new_party + $total_box + $trip1 + $b + $dress + $max_profit + $max_average;
                                        ?>
                                        <div class="cat-3">
                                            <table class="dtr table table-striped">
                                                <tr>
                                                    <th><?php echo $role; ?>:</th>
                                                    <td></td>
                                                    <th style="width:7rem; font-weight: bolder; color: rgb(46, 46, 128);"><?php echo $emp_name; ?></th>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Morning Time :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $mt; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Evening Time :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $et; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Whatsup :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $wate; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>New party :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $new_party; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Total box 200/250 :</span><span>4</span></th>
                                                    <td></td>
                                                    <td><?php echo $total_box; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Trip 1/2 :</span><span>4</span></th>
                                                    <td></td>
                                                    <td><?php echo $trip1; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Bottle/box/cap :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $b; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Dress :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $dress; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Max profit :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $max_profit; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><span>Max average price :</span><span>2</span></th>
                                                    <td></td>
                                                    <td><?php echo $max_average; ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="display:flex; justify-content: space-between;"><strong>No. of Discipline :</strong></th>
                                                    <td></td>
                                                    <td><strong><?php echo $total_credit; ?></strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                }
            }
        }
        ?>
        </div>
        <div style="width: 50%; margin-bottom: 2rem;">
            <div style="display: flex;justify-content: center;gap: 2rem;margin-top: 2rem;" class=" ">
                <button onclick="myprint()" type="button" class="btn btn-success w-25">Print</button>
                <a href="d_report.php" class="w-25"><button type="button" class="btn btn-danger w-100">Cancel</button></a>
            </div>
        </div>
    </main>

    <footer></footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script>
        function myprint() {
            var backup = document.body.innerHTML;
            var content = document.getElementById("printcontent").innerHTML;

            document.body.innerHTML = content;
            window.print();
            document.body.innerHTML = backup;
        }
    </script>
</body>

</html>
<?php
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/log.svg">
  <link rel="icon" type="image/png" href="assets/img/log.svg">
  <title>
    OceanGelide
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="https://demos.creative-tim.com/argon-dashboard-pro/assets/css/nucleo-icons.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/argon-dashboard.css?v=2.1.0" rel="stylesheet" />
  <style>
    #ham{
      border: 1px solid white;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      color: black;
      text-align: center;
      background: #fff;
      justify-content: center;
      align-content: center;
      display: none;
    }
    @media only screen and (max-width: 1200px) {
      #ham{
        display: block;
      }
    }
  </style>
</head>

<body class="g-sidenav-show   bg-gray-100">
  <div class="min-height-300 bg-dark position-absolute w-100"></div>
  <aside id="aside" class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 " id="sidenav-main">
    <div class="sidenav-header p-3">
      
      <img style="width: 31px;" src="assets/img/log.svg" alt="">
      <span class="app-text">OceanGelide</span>

    </div>
    <hr class="horizontal dark mt-0">
    <div class="collapse navbar-collapse  w-auto " style=" height: auto;" id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?php if($active == 1) echo 'active' ;?> " href="index.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-tv-2 text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active ==2) echo 'active' ;?> " href="rates.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-calendar-grid-58 text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Rates</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 14) echo 'active' ;?> " href="edit_emp.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="fa-solid fa-user text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Update Employee</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 15){ echo 'active' ;}?> " href="edit_gadi.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="fa-solid fa-truck text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Update Gadi</span>
          </a>
        </li>

        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Entery : </h6>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if($active == 5) echo 'active' ;?> " href="entry.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="fa-solid fa-book text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Challan Entery</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 12) echo 'active' ;?> " href="emp_credit_entry.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="fa-solid fa-book text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Credit Entery</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 6) echo 'active' ;?> " href="edit_entry.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-app text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Update Challan </span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 13) echo 'active' ;?> " href="edit_credits.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-app text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Update Credit </span>
          </a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link <?php// if($active == 11) echo 'active' ;?> " href="delete_ent.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-world-2 text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Delete Challan</span>
          </a>
        </li> -->
        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Reports </h6>
        </li>
        
        <li class="nav-item">
          <a class="nav-link <?php if($active == 16) echo 'active' ;?> " href="emp_performance.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="fa-solid fa-chart-simple text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Emp performance</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 7) echo 'active' ;?> " href="pl_report.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-single-copy-04 text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">PL Report</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 9) echo 'active' ;?> relative" href="d_report.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-single-copy-04 text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Day Report</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($active == 8) echo 'active' ;?> " href="m_report.php">
            <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
              <i class="ni ni-collection text-dark text-sm opacity-10"></i>
            </div>
            <span class="nav-link-text ms-1">Report</span>
          </a>
        </li>
        
      </ul>
    </div>
    <!-- <div class="sidenav-footer mx-3 " style="position: fixed;;">
      
      <a href="https://www.creative-tim.com/learning-lab/bootstrap/license/argon-dashboard" target="_blank" class="btn btn-dark btn-sm w-100 mb-3">Documentation</a>
      <a class="btn btn-primary btn-sm mb-0 w-100" href="https://www.creative-tim.com/product/argon-dashboard-pro?ref=sidebarfree" type="button">Upgrade to pro</a>
    </div> -->
  </aside>
  <main class="main-content position-relative border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl " id="navbarBlur" data-scroll="false">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm opacity-5 text-white">Hello!, <?php echo $_SESSION['id']?></li>
          </ol>
          <h6 class="font-weight-bolder text-white mb-0">TRUPTI BEVERAGES 212/5,GRAM PALDA INDORE (M.P.)</h6>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
            <div class="input-group">
              <span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span>
              <input type="text" class="form-control" placeholder="Type here...">
            </div>
          </div>
          <ul class="navbar-nav gap-4 justify-content-end">
            
            <li class="nav-item d-flex align-items-center">
              <a href="logout.php" class="nav-link text-white font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Log out</span>
              </a>
            </li>
            <li id="ham" class="nav-item align-items-center" style="">
                <i class="fa-solid fa-bars nav-link text-black font-weight-bold px-0" style="font-size: large;"></i>
            </li>
        
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->

    <Script>
     const hamButton = document.getElementById('ham');
    const asideElement = document.getElementById('aside');

    // Add click event listener to the button
    hamButton.addEventListener('click', () => {
      // Toggle the 'sidenav' class
      asideElement.classList.toggle('sidenav');
    });
    </Script>

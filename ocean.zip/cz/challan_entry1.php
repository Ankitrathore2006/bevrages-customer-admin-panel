<?php
include("session.php"); 

include("db.php");
// include("header.php");
?><?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect URL parameters
    $employee_name = $_GET['employee_name'];
    $date = $_GET['date'];
   

    // Insert into `daily_challan`
    $sql_challan = "INSERT INTO `daily_challan`(`salesman`,`driver`, `1l`, `500ml`, `250ml`, `2l`, `coldd`, `challan_no`, `gadi_no`, `d_cash`, `d_online`, `udari`, `date`) 
                    VALUES ('$employee_name', '$one_liter', '$half_liter', '$quarter_liter', '$two_liter', '$cold_drink', '$challan_no', '$gadi_no', '$case', '$account', '$udhari', '$date')";
    $result_challan = mysqli_query($conn, $sql_challan);

    if ($result_challan) {
        echo "<script>
                alert('Successfully Added!');
                window.location.href='challan_entry.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
}
?>

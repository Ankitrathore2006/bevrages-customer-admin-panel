<?php
include("session.php"); 

include("db.php");
$active = 7;

if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

?>

<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Daily PL Report</li>
    </ol>
</div>


<div class="row m-4 d-flex justify-content-center align-items-center">

    <div class="col-lg-7 my-4">
        <form autocomplete="off" method="get" action="daily_challan.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0"> Enter details : </h6>
                </div>
                <div class="card-body p-3 d-flex flex-column justify-content-evenly gap-3 align-items-center">

                    <div class="form-group w-40">
                        <label for="gadiNo" style="margin-bottom: 8px;">Gadi no. :</label>
                        <select class="form-select" name="gadi_no" id="gadiNo" aria-label="Default select example">
                            <option value="NA"></option>
                            <?php 
                                $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
                                $query = mysqli_query($conn,$sql);
                                while($row = mysqli_fetch_assoc($query)){
                                ?>
                            <option value="<?php echo $row['gadi_no']; ?>" class="form-select">

                                <?php echo $row['gadi_no']; ?>
                            </option>
                            <?php  }?>
                        </select>
                    </div>
                    <div class="form-group w-40">
                        <label for="date" style="margin-bottom: 8px;">Date : </label>
                        <input type="date" class="form-control" name="date">
                    </div>
                   

                </div>
                <div style="display: flex; justify-content: center;" class="row-1 d-flex mb-4 ">
                    <button type="submit" class="btn btn-primary w-30">Submit</button>
                </div>
            </div>
        </form>
    </div>

</div>


<?php
include("footer.php");
?>
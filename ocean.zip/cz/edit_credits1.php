<?php
include("session.php"); 

$active = 13;
include("db.php");
if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

if (isset($_GET['salesman_name']) || isset($_GET['Sequence_no']) || isset($_GET['challan_no']) || isset($_GET['gadi_no']) || isset($_GET['date'])) {
    $salesman_name = $sequence_no = $challan_no = $gadi_no = $date = "";
    $salesman_name = mysqli_real_escape_string($conn, $_GET['salesman_name']);
    $sequence_no = mysqli_real_escape_string($conn, $_GET['Sequence_no']);
    $challan_no = mysqli_real_escape_string($conn, $_GET['challan_no']);
    $gadi_no = mysqli_real_escape_string($conn, $_GET['gadi_no']);
    $date = mysqli_real_escape_string($conn, $_GET['date']);
?>

<div class="row mt-4 w-100">

    <div class="col-lg-11 mb-lg-0 m-5">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">Employee Credits</h6>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-items-center ">
                    <thead class="mb-5">
                        <tr>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Action</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Sequence No.</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Emp Name</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Gadi No.</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Challan No.</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Morning Time</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Evening Time</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Wate</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">New Party</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Total Box</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Trip 1/2</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">B/C</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Dress</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Max Profit</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Max Average</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Role</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Date</p>
                                </div>
                            </td>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $sql = "SELECT `id`,`Sequence_no`, `emp_name`, `gadi_no`, `challan_no`, `mt`, `et`, `wate`, `new_party`, `total_box`, `trip1/2`, `b/c`, `dress`, `max_profit`, `max_average`, `role`, `date` FROM `daily_credit` WHERE 1 = 1";

                        if ($salesman_name != "NA") {
                            $sql .= " AND `emp_name` = '" . mysqli_real_escape_string($conn, $salesman_name) . "'";
                        }
                        if (!empty($sequence_no)) {
                            $sql .= " AND `Sequence_no` = '" . mysqli_real_escape_string($conn, $sequence_no) . "'";
                        }
                        if (!empty($challan_no)) {
                            $sql .= " AND `challan_no` = '" . mysqli_real_escape_string($conn, $challan_no) . "'";
                        }
                        if ($gadi_no != "NA") {
                            $sql .= " AND `gadi_no` = '" . mysqli_real_escape_string($conn, $gadi_no) . "'";
                        }
                        if (!empty($date)) {
                            $sql .= " AND `date` = '" . mysqli_real_escape_string($conn, $date) . "'";
                        }

                        $query = mysqli_query($conn, $sql);
                        if ($query && mysqli_num_rows($query) > 0) {
                            while ($row = mysqli_fetch_assoc($query)) {
                        ?>
                        <tr>
                            <td>
                                <div class="text-center">
                                    <a href="edit_credits2.php?id=<?php echo $row['id']; ?>">
                                        <button type="button" class="btn btn-secondary">Edit</button></a>
                                    <a
                                        href="delete_entry.php?id=<?php echo $row['Sequence_no']; ?>&str=employees credits">
                                        <button type="button" class="btn btn-danger">Delete</button></a>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['Sequence_no']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['emp_name']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['gadi_no']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['challan_no']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['mt']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['et']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['wate']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['new_party']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['total_box']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['trip1/2']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['b/c']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['dress']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['max_profit']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['max_average']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['role']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['date']; ?></h6>
                                </div>
                            </td>
                        </tr>
                        <?php } } else {
                            echo "<tr><p class='text-center'>No records found for the provided details.</p></tr>";
                        }
                    }
                        ?>
                        <tr>
                          
                        
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <!-- <td>
                                <div class="text-center">
                                </div>
                            </td> -->
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
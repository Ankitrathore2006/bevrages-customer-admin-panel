<?php
include("session.php"); 

$active =12;
include("db.php");

if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

?>


<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Challan Entry</li>
    </ol>
</div>


<div class="row m-4 d-flex justify-content-center align-items-center">

    <div class="col-lg-9 my-4 ">
        <form autocomplete="off" method="get" action="entry1.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Enter Creadits : </h6>
                </div>
                <div class="card-body p-3 d-flex justify-content-evenly gap-3 align-items-center">
                <?php 

                        $sequence = 1; // Default starting sequence number
                        $ch_Sequence_no = 0;
                        $ch_challan_no = 0;
                        $ch_gadi_no  ="";
                        $ch_salesman  ="";
                        $ch_driver = "";
                        $ch_date = "";

                        // Fetch the maximum sequence number from daily_credit
                        $sql = "SELECT MAX(`Sequence_no`) as max_ch_no, MAX(`challan_no`) as max_challan FROM `daily_credit`;";
                        $query = mysqli_query($conn, $sql);

                        if ($query) {
                            $row = mysqli_fetch_assoc($query);
                            $sequence = isset($row['max_ch_no']) ? $row['max_ch_no'] + 1 : 1;
                            $chalan = isset($row['max_challan']) ? $row['max_challan'] + 1 : 1;

                            while (true) {
                                $sql_check1 = "SELECT `id` FROM `daily_challan` WHERE `challan_no` = '$chalan' AND `type` = 'self';";
                                $query_check1 = mysqli_query($conn, $sql_check1);

                                if ($query_check1 && mysqli_num_rows($query_check1) > 0) {
                                    $chalan++;  
                                }else{
                                    break;
                                }

                            }
                            // Loop until a sequence number with type 'company' is found
                            while (true) {
                                $sql_check = "SELECT `type` FROM `daily_challan` WHERE `Sequence_no` = '$sequence';";
                                $query_check = mysqli_query($conn, $sql_check);
                                
                                if ($query_check) {
                                    $row_check = mysqli_fetch_assoc($query_check);
                                    if (isset($row_check['type']) && $row_check['type'] == 'self') {
                                        $sequence++; // Skip if type is 'self'

                                    } else{
                                        $ch_Sequence_no = $sequence;
                                        $ch_challan_no = $chalan;
                                        $sql_details = "SELECT `Sequence_no`, `salesman`, `driver`, `challan_no`, `gadi_no`, `date` FROM `daily_challan` WHERE `Sequence_no` = '$sequence';";
                                        $query_details = mysqli_query($conn, $sql_details);
                                        if ($query_details) {
                                            while ($details_row = mysqli_fetch_assoc($query_details)) {
                                                $ch_Sequence_no = $details_row['Sequence_no'];
                                                $ch_challan_no = $details_row['challan_no'];
                                                $ch_gadi_no  = $details_row['gadi_no'];
                                                $ch_salesman  = $details_row['salesman'];
                                                $ch_driver = $details_row['driver'];
                                                $ch_date = $details_row['date'];                                                
      
                                            }
                                        }
                                        break;
                                    } 
    
                                } else {
                                    echo "Error checking sequence: " . mysqli_error($conn);
                                    break;
                                }
                            }
                            } else {
                            echo "Error fetching data: " . mysqli_error($conn);
                            }
    
                        ?>


                    <div style=" width: 18rem;">
        

                        <div class="form-group">
                            <label for="gadiNo" style="margin-bottom: 8px;">Gadi no. :</label>
                            <select class="form-select" name="gadi_no" id="gadiNo" aria-label="Default select example"
                                required>
                                <option value="NA"></option>
                                <?php 
                                $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
                                $query = mysqli_query($conn,$sql);
                                $selectprint="";
                                
                                while($row = mysqli_fetch_assoc($query)){
                                    
                                ?>
                                <option <?php echo ($row['gadi_no'] == $ch_gadi_no)? "selected" : ""; ?>
                                    <?php echo $row['gadi_no']; ?> value="<?php echo $row['gadi_no']; ?>"
                                    class="form-select">

                                    <?php echo $row['gadi_no']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="gadiDate" style="margin-bottom: 8px;">Date :</label>
                            <input type="date" value="<?php echo $ch_date; ?>" name="gadi_date" class="form-control"
                                id="date-picker" min="2014-01-01" max="" required>
                        </div>

                        <strong>DRIVER DETAILS :</strong>
                        <div class="form-group">
                            <label for="driverName" style="margin-bottom: 8px;">Employee Name :</label>
                            <select class="form-select" name="driver_name" id="driverName"
                                aria-label="Default select example" required>
                                <option value="NA"></option>
                                <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'company';";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                <option <?php echo ($row['name'] == $ch_driver)? "selected" : ""; ?>
                                    value="<?php echo $row['name']; ?>" class="form-select">
                                    <?php echo $row['name']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="morningTimeDriver" style="margin-bottom: 8px;">Morning Time :</label>
                            <input type="number" name="driver_morning_time" class="form-control" id="morningTimeDriver"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="eveningTimeDriver" style="margin-bottom: 8px;">Evening Time :</label>
                            <input type="number" name="driver_evening_time" class="form-control" id="eveningTimeDriver"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="wakeUpDriver" style="margin-bottom: 8px;">Whatsup :</label>
                            <input type="number" name="driver_wake_up" class="form-control" id="wakeUpDriver" value="0"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="newPartyDriver" style="margin-bottom: 8px;">New Party :</label>
                            <input type="number" name="driver_new_party" class="form-control" id="newPartyDriver"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="totalBoxDriver" style="margin-bottom: 8px;">Total box 200/250 :</label>
                            <input type="number" name="driver_total_box" class="form-control" id="totalBoxDriver"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="tripDriver" style="margin-bottom: 8px;">Trip 1/2 :</label>
                            <input type="number" name="driver_trip" class="form-control" id="tripDriver" value="0"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="bottleBoxCapDriver" style="margin-bottom: 8px;">Bottle/box/cap :</label>
                            <input type="number" name="driver_bottle_box_cap" class="form-control"
                                id="bottleBoxCapDriver" value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="dressDriver" style="margin-bottom: 8px;">Dress :</label>
                            <input type="number" name="driver_dress" class="form-control" id="dressDriver" value="0"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="maxProfitDriver" style="margin-bottom: 8px;">Max profit :</label>
                            <input type="number" name="driver_max_profit" class="form-control" id="maxProfitDriver"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="maxAveragePriceDriver" style="margin-bottom: 8px;">Max average price :</label>
                            <input type="number" name="driver_max_avg_price" class="form-control"
                                id="maxAveragePriceDriver" value="0" required>
                        </div>
                    </div>
                    <div style=" width: 18rem;">

                        <div class="form-group">
                            <label for="challan_no" style="margin-bottom: 8px;">Challan no:</label>
                            <input type="text" name="challan_no" value="<?php echo $ch_challan_no; ?>" class="form-control"
                                id="challan_no" required>
                        </div>


                        <div class="form-group">
                            <label for="Sequence_no" style="margin-bottom: 8px;">Sequence no. :</label>
                            <input type="number" name="Sequence_no" class="form-control" id="Sequence_no"
                                value="<?php echo $ch_Sequence_no; ?>"  required>
                        </div>


                        <strong>SALES MAN DETAILS :</strong>
                        <div class="form-group">
                            <label for="salesmanName" style="margin-bottom: 8px;">Employee Name :</label>
                            <select class="form-select" name="salesman_name" id="salesmanName"
                                aria-label="Default select example" required>
                                <option value="NA"></option>
                                <?php 
                            $sql = "SELECT `emp_id`,`name` FROM `employee`WHERE `type` = 'company';";
                            $query = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_assoc($query)){
                            ?>
                                <option <?php echo ($row['name'] == $ch_salesman)? "selected" : ""; ?>
                                    value="<?php echo $row['name']; ?>" class="form-select">
                                    <?php echo $row['name']; ?>
                                </option>
                                <?php  }?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="morningTimeSalesman" style="margin-bottom: 8px;">Morning Time :</label>
                            <input type="number" name="salesman_morning_time" class="form-control"
                                id="morningTimeSalesman" value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="eveningTimeSalesman" style="margin-bottom: 8px;">Evening Time :</label>
                            <input type="number" name="salesman_evening_time" class="form-control"
                                id="eveningTimeSalesman" value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="wakeUpSalesman" style="margin-bottom: 8px;">Whatsup :</label>
                            <input type="number" name="salesman_wake_up" class="form-control" id="wakeUpSalesman"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="newPartySalesman" style="margin-bottom: 8px;">New Party :</label>
                            <input type="number" name="salesman_new_party" class="form-control" id="newPartySalesman"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="totalBoxSalesman" style="margin-bottom: 8px;">Total box 200/250 :</label>
                            <input type="number" name="salesman_total_box" class="form-control" id="totalBoxSalesman"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="tripSalesman" style="margin-bottom: 8px;">Trip 1/2 :</label>
                            <input type="number" name="salesman_trip" class="form-control" id="tripSalesman" value="0"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="bottleBoxCapSalesman" style="margin-bottom: 8px;">Bottle/box/cap :</label>
                            <input type="number" name="salesman_bottle_box_cap" class="form-control"
                                id="bottleBoxCapSalesman" value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="dressSalesman" style="margin-bottom: 8px;">Dress :</label>
                            <input type="number" name="salesman_dress" class="form-control" id="dressSalesman" value="0"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="maxProfitSalesman" style="margin-bottom: 8px;">Max profit :</label>
                            <input type="number" name="salesman_max_profit" class="form-control" id="maxProfitSalesman"
                                value="0" required>
                        </div>
                        <div class="form-group">
                            <label for="maxAveragePriceSalesman" style="margin-bottom: 8px;">Max average price :</label>
                            <input type="number" name="salesman_max_avg_price" class="form-control"
                                id="maxAveragePriceSalesman" value="0" required>
                        </div>
                    </div>
                    
                </div>
                <div style="display: flex; justify-content: center;" class="row-1 d-flex mb-4">
                    <button type="submit" class="btn btn-primary w-50">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
        include("footer.php");
        ?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
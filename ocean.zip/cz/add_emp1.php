<?php
include("session.php"); 

include("db.php");
?>
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect URL parameters
    $employee_name = $_GET['employee_name'];
    $j_date = $_GET['j_date'];
    $mobile_no = $_GET['mobile_no'];
    $adhar = $_GET['adhar'];
    $address = $_GET['address'];
    $type = $_GET['type'];

    // Insert into `daily_challan`
    $sql_challan = "INSERT INTO `employee`( `name`, `mobile`, `address`, `adhar`,`type`,`joining_date`) 
    VALUES ('$employee_name','$mobile_no','$address','$adhar','$type','$j_date')";
    $result_challan = mysqli_query($conn, $sql_challan);

    if ($result_challan) {
        echo "<script>
                alert('Successfully Added!');
                window.location.href='add_emp.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
}

?>
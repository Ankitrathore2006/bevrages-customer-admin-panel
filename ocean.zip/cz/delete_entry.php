<?php
include("session.php"); 

include("db.php");
?>
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect URL parameters
    $id = $_GET['id'];
    $str = $_GET['str'];

    if($str == "employee"){
        $sql_challan = "DELETE FROM `employee` WHERE `emp_id`='$id';";
        $result_challan = mysqli_query($conn, $sql_challan);

        if ($result_challan) {
            echo "<script>
                    alert('Successfully Deleted !');
                    window.location.href='add_emp.php';
                </script>";
        } else {
            echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
        }
    }else if($str == "gadi"){
        $sql_challan = "DELETE FROM `gadi_detail` WHERE `id`='$id';";
        $result_challan = mysqli_query($conn, $sql_challan);

        if ($result_challan) {
            echo "<script>
                    alert('Successfully Deleted !');
                    window.location.href='add_gadi.php';
                </script>";
        } else {
            echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
        }
    }else if($str == "challan"){
        $type = $_GET['type'];
        if ($str == "self") {

            $sql_challan = "DELETE FROM `daily_challan` WHERE `Sequence_no`='$id';";
            $result_challan = mysqli_query($conn, $sql_challan);

            if ($result_challan) {
                echo "<script>
                        alert('Successfully Deleted !');
                        window.location.href='edit_entry.php';
                    </script>";
            } else {
                echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
            }
        }else{
            $sql_challan = "DELETE FROM `daily_challan` WHERE `Sequence_no`='$id';";
            $result_challan = mysqli_query($conn, $sql_challan);

            $sql_exp = "DELETE FROM `daily_exp` WHERE `Sequence_no`='$id';";
            $result_exp = mysqli_query($conn, $sql_exp);
    
            if ($result_exp && $result_challan) {
                echo "<script>
                        alert('Successfully Deleted !');
                        window.location.href='edit_entry.php';
                    </script>";
            } else {
                echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
            }
        }

    }else if($str == "employees credits"){
        $sql_challan = "DELETE FROM `daily_credit` WHERE `Sequence_no`='$id';";
        $result_challan = mysqli_query($conn, $sql_challan);

        if ($result_challan) {
            echo "<script>
                    alert('Successfully Deleted !');
                    window.location.href='edit_credits.php';
                </script>";
        } else {
            echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
        }
    }
    
}

?>
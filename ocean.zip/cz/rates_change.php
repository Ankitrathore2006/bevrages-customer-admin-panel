<?php
include("session.php"); 

include("db.php");
?>
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $one_liter = $_GET['one_liter'];
    $half_liter = $_GET['half_liter'];
    $quarter_liter = $_GET['quarter_liter'];
    $two_liter = $_GET['two_liter'];
    $cold_drink = $_GET['cold_drink'];

    $sql_challan = "INSERT INTO `rate` (`1l`, `500ml`, `250ml`, `2l`, `col`) 
    VALUES ('$one_liter', '$half_liter', '$quarter_liter', '$two_liter', '$cold_drink');";
    $result_challan = mysqli_query($conn, $sql_challan);

    if ($result_challan) {
        echo "<script>
                alert('Successfully Added!');
                window.location.href='rates.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
}

?>
<?php
include("session.php"); 

include("db.php");

// Ensure the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {

    // Fetch and sanitize input data using URL parameters
    $gadi_no = mysqli_real_escape_string($conn, $_GET['gadi_no']);
    $gadi_date = mysqli_real_escape_string($conn, $_GET['gadi_date']);
    $challan_no = mysqli_real_escape_string($conn, $_GET['challan_no']);
    $sequence_no = mysqli_real_escape_string($conn, $_GET['Sequence_no']);
    
    // Salesman data
    $salesman_name = mysqli_real_escape_string($conn, $_GET['salesman_name']);
    $salesman_morning_time = mysqli_real_escape_string($conn, $_GET['salesman_morning_time']);
    $salesman_evening_time = mysqli_real_escape_string($conn, $_GET['salesman_evening_time']);
    $salesman_wake_up = mysqli_real_escape_string($conn, $_GET['salesman_wake_up']);
    $salesman_new_party = mysqli_real_escape_string($conn, $_GET['salesman_new_party']);
    $salesman_total_box = mysqli_real_escape_string($conn, $_GET['salesman_total_box']);
    $salesman_trip = mysqli_real_escape_string($conn, $_GET['salesman_trip']);
    $salesman_bottle_box_cap = mysqli_real_escape_string($conn, $_GET['salesman_bottle_box_cap']);
    $salesman_dress = mysqli_real_escape_string($conn, $_GET['salesman_dress']);
    $salesman_max_profit = mysqli_real_escape_string($conn, $_GET['salesman_max_profit']);
    $salesman_max_avg_price = mysqli_real_escape_string($conn, $_GET['salesman_max_avg_price']);

    // Driver data
    $driver_name = mysqli_real_escape_string($conn, $_GET['driver_name']);
    $driver_morning_time = mysqli_real_escape_string($conn, $_GET['driver_morning_time']);
    $driver_evening_time = mysqli_real_escape_string($conn, $_GET['driver_evening_time']);
    $driver_wake_up = mysqli_real_escape_string($conn, $_GET['driver_wake_up']);
    $driver_new_party = mysqli_real_escape_string($conn, $_GET['driver_new_party']);
    $driver_total_box = mysqli_real_escape_string($conn, $_GET['driver_total_box']);
    $driver_trip = mysqli_real_escape_string($conn, $_GET['driver_trip']);
    $driver_bottle_box_cap = mysqli_real_escape_string($conn, $_GET['driver_bottle_box_cap']);
    $driver_dress = mysqli_real_escape_string($conn, $_GET['driver_dress']);
    $driver_max_profit = mysqli_real_escape_string($conn, $_GET['driver_max_profit']);
    $driver_max_avg_price = mysqli_real_escape_string($conn, $_GET['driver_max_avg_price']);

    // Insert data into `daily_credit` table
    $sql_salesman = "INSERT INTO `daily_credit` 
                     (`Sequence_no`, `emp_name`, `gadi_no`, `challan_no`, `mt`, `et`, `wate`, `new_party`, 
                     `total_box`, `trip1/2`, `b/c`, `dress`, `max_profit`, `max_average`, `role`, `date`) 
                     VALUES 
                     ('$sequence_no','$salesman_name','$gadi_no','$challan_no','$salesman_morning_time',
                      '$salesman_evening_time','$salesman_wake_up','$salesman_new_party','$salesman_total_box',
                      '$salesman_trip','$salesman_bottle_box_cap','$salesman_dress','$salesman_max_profit',
                      '$salesman_max_avg_price','Salesman','$gadi_date')";

    $result_salesman = mysqli_query($conn, $sql_salesman);

    // Insert driver data
    $sql_driver = "INSERT INTO `daily_credit` 
                   (`Sequence_no`, `emp_name`, `gadi_no`, `challan_no`, `mt`, `et`, `wate`, `new_party`, 
                   `total_box`, `trip1/2`, `b/c`, `dress`, `max_profit`, `max_average`, `role`, `date`) 
                   VALUES 
                   ('$sequence_no','$driver_name','$gadi_no','$challan_no','$driver_morning_time',
                    '$driver_evening_time','$driver_wake_up','$driver_new_party','$driver_total_box',
                    '$driver_trip','$driver_bottle_box_cap','$driver_dress','$driver_max_profit',
                    '$driver_max_avg_price','Driver','$gadi_date')";

    $result_driver = mysqli_query($conn, $sql_driver);

    // Validate results and provide feedback
    if ($result_salesman && $result_driver) {
        echo "<script>
                alert('Successfully updated!');
                window.location.href='emp_credit_entry.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong. Error: " . mysqli_error($conn) . "')</script>";
    }
}
?>

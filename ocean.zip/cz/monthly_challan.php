<?php
include("session.php"); 

include("db.php");
?><?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $namme = $_GET['name'];
    if (!empty($_GET['date'])){
        $date = $_GET['date'];
        $month = substr($date,5,2);
        $Searchmonth = $date.'%';
    }
    if (!empty($_GET['from'])){
        $from= $_GET['from'];
        $to = $_GET['to'];
        $toDate = $to;  
        $newto = date("d-m-Y", strtotime($toDate));  
        $fromDate = $from;  
        $newfrom = date("d-m-Y", strtotime($fromDate));  
    }

        $query2 = "SELECT `type` FROM `employee` WHERE `name` = '$namme' LIMIT 1;";
        $query_run2 = mysqli_query($conn, $query2);
        $row2 = mysqli_fetch_array($query_run2);
        if($namme == "All Employee"){
            $type = "company";
        }else{
            $type = $row2['type'];
        }
    
    ?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="//cdn.datatables.net/2.1.3/css/dataTables.dataTables.min.css" rel="stylesheet">
    <title>oceangelide</title>
    <style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    .cat-1,
    .cat-2,
    .cat-3,
    .cat-4 {
        margin: 5px;
    }

    .cont {
        display: flex;
        justify-content: space-between;
        margin-top: 10px;
    }

    .dt-layout-start {
        display: none !important;
    }

    th {
        font-weight: 900;
    }
    </style>
</head>

<body>


    <main style="display: flex;flex-direction: column;justify-content: center;align-items: center;">

        <div id="printcontent" style="width:100%; ">
            <div style="margin: 1rem;    width: fit-content;
                        border: 2px solid black; padding: 2px; height: 95vh; overflow: auto; font-size: small;">

                <span
                    style="display: flex; justify-content: center; font-size: 1.5rem; padding: 10px 0px; font-weight: bolder; color: rgb(20, 20, 163);">TRUPTI
                    BEVERAGES 212/5,GRAM PALDA INDORE (M.P.)</span>

                <div style="display: flex; justify-content: space-around;" class="row-1 d-flex ">
                    <?php
                 if (!empty($_GET['date'])){
                  ?>
                    <span><strong>Month : </strong> <?php echo date("F",mktime(0,0,0,$month,10)); ?></span>
                    <span><strong>Year : </strong> <?php echo substr($date,0,4) ;?></span>
                    <?php
                    }else{
                        ?>
                    <span><strong>Date range : </strong> <?php echo $newfrom." - ".$newto;?></span>
                    <?php
               }
                ?>
                    <span><strong>Employee Name : </strong> <?php echo $namme ;?></span>
                </div>
                <div class="cont">
                    <table id="example" style="width: 95vw;" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Challan</th>
                                <th>1 ltr</th>
                                <th>500 ml</th>
                                <th>250 ml</th>
                                <th>2 ltr</th>
                                <th>Cold drink</th>
                                <th>Kul peti</th>
                                <?php
                                if($type == "self"){
                                ?>
                                <th>1 ltr rate</th>
                                <th>500 ml rate</th>
                                <th>250 ml rate</th>
                                <th>2 ltr rate</th>
                                <th>cold drink rate</th>
                                <?php
                                    }
                                ?>
                                <th>Amount</th>
                                <th>Deposit</th>
                                <?php
                                if($type == "company"){
                                ?>
                                <th>Total exp.</th>
                                <?php
                                    }
                                ?>
                                <th>Udari</th>
                                <?php
                                if($type == "company"){
                                ?>
                                <th>Name</th>
                                <?php
                                    }
                                ?>
                                <?php
                                if($namme == "All Employee"){
                                    ?>
                                <th>Driver Name</th>
                                <th>Driver Discipline</th>
                                <th>Salesman Name</th>
                                <th>Salesman Discipline</th>
                                <?php
                                }else{
                                    if($type == "company"){
                                    ?>
                                <th>Discipline</th>
                                <?php
                                    }
                                }
                            ?>
                                <th>Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                        if($namme == "All Employee"){
                            if (!empty($_GET['date'])){
                                $query = "SELECT * FROM `daily_challan` dc INNER JOIN daily_exp de ON dc.Sequence_no = de.Sequence_no AND dc.challan_no = de.challan_no AND dc.date = de.date AND dc.gadi_no= de.gadi_no WHERE  dc.date LIKE '$Searchmonth' ORDER BY dc.challan_no ASC;";
                                }else{
                                $query = " SELECT * FROM `daily_challan` dc INNER JOIN daily_exp de ON dc.Sequence_no = de.Sequence_no AND dc.challan_no = de.challan_no AND dc.date = de.date AND dc.gadi_no= de.gadi_no WHERE  dc.date BETWEEN '$from' AND '$to' ORDER BY dc.challan_no ASC;"; 
                            }
                            $query_run = mysqli_query($conn,$query);      
                            if(mysqli_num_rows($query_run) > 0)
                            {
                                while($row = mysqli_fetch_array($query_run))
                                {
                                    $Sequence_no = $row['Sequence_no'];
                                    $onel = $row['1l'];
                                    $halfml = $row['500ml'];
                                    $quatml = $row['250ml'];
                                    $twol = $row['2l'];
                                    $coldd = $row['coldd'];
                                    $challan_no = $row['challan_no'];
                                    $d_cash = $row['d_cash'];
                                    $d_online = $row['d_online'];
                                    $udari = $row['udari'];
                                    $gadi_no = $row['gadi_no'];
                                    $gadi_exp = $row['gadi_exp'];
                                    $diesel = $row['diesel'];
                                    $toll = $row['toll'];
                                    $s_man = $row['s_man'];
                                    $chai_pani = $row['chai_pani'];
                                    $other_exp = $row['other_exp'];
                                    $Name = $row['Name'];
                                    $ddate = $row['date']; 
                                    $newDate = date("d-m-Y", strtotime($ddate)); 

                                    $query1 = "SELECT *  FROM `rate` WHERE `date` <= '$ddate' ORDER BY id DESC LIMIT 1;";
                                    $query_run1 = mysqli_query($conn, $query1);
                                        $row = mysqli_fetch_array($query_run1);
                                            $r_onel = $row['1l'];
                                            $r_halfml = $row['500ml'];
                                            $r_quatml = $row['250ml'];
                                            $r_twol = $row['2l'];
                                            $r_coldd = $row['col'];
                                     ?>
                                    <tr>
                                        <td><?php echo $newDate ;?></td>
                                        <td><?php echo $challan_no ;?></td>
                                        <td><?php echo $onel ;?> </td>
                                        <td><?php echo $halfml ;?> </td>
                                        <td><?php echo $quatml ;?> </td>
                                        <td><?php echo $twol ;?></td>
                                        <td><?php echo $coldd ;?></td>
                                        <td><?php echo $onel+$halfml+$quatml+$twol+$coldd ;?></td>
                                        <?php
                                        if($type == "self"){
                                        ?>
                                        <td><?php echo $r_onel ;?> </td>
                                        <td><?php echo $r_halfml ;?> </td>
                                        <td><?php echo $r_quatml ;?> </td>
                                        <td><?php echo $r_twol ;?></td>
                                        <td><?php echo $r_coldd ;?></td>
                                        <?php
                                            }
                                        ?>
                                        <td><?php $P_1l=$onel*$r_onel;$P_500ml= $halfml*$r_halfml ; $P_250l= $quatml*$r_quatml ;$P_2l= $twol*$r_twol ; $P_col= $coldd*$r_coldd ;  $total_ammt=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col; echo $total_ammt;?>
                                        </td>
                                        <td><?php $total_coll = $d_cash+$d_online+$udari+$Name ; echo $total_coll;?></td>
                                        <?php if($type == "company"){ ?>
                                        <td><?php $total_ex = $gadi_exp+$diesel+$toll+$s_man+$chai_pani+$other_exp; echo $total_ex+$P_1l+$P_250l+$P_500ml+$P_2l+$P_col ;?>
                                        </td>
                                        <?php } ?>
                                        <td><?php echo $udari ;?></td>

                                        <?php
                                        if($type == "company"){
                                        ?>
                                        <td><?php echo $Name ;?></td>
                                        <?php
                                            }
                                        if (!empty($_GET['date'])){
                                            $query_credit = "SELECT * FROM daily_credit WHERE  Sequence_no='$Sequence_no' AND gadi_no='$gadi_no' AND  challan_no='$challan_no' AND date = '$ddate'";
                                            }else{
                                            $query_credit = "SELECT * FROM daily_credit WHERE Sequence_no='$Sequence_no' AND gadi_no='$gadi_no' AND challan_no='$challan_no' AND date BETWEEN '$from' AND '$to'";          
                                        }
                                            $query_run_credit = mysqli_query($conn, $query_credit);
                                            if (mysqli_num_rows($query_run_credit) > 0) {
                                                while ($row_credit = mysqli_fetch_array($query_run_credit)) {
                                                    $emp_name = $row_credit['emp_name'];
                                                    $mt = $row_credit['mt'];
                                                    $et = $row_credit['et'];
                                                    $wate = $row_credit['wate'];
                                                    $new_party = $row_credit['new_party'];
                                                    $total_box = $row_credit['total_box'];
                                                    $trip1 = $row_credit['trip1/2'];
                                                    $b = $row_credit['b/c'];
                                                    $dress = $row_credit['dress'];
                                                    $max_profit = $row_credit['max_profit'];
                                                    $max_average = $row_credit['max_average'];
                                                    $role = $row_credit['role'];
                                                    $total_credit = $mt + $et + $wate + $new_party + $total_box + $trip1 + $b + $dress + $max_profit + $max_average;
                                                    ?>
                                                <td><?php echo $emp_name;?></td>
                                                <td><?php echo $total_credit ;?></td>
                                                <?php
                                                }
                                            } ?>

                                        <td class=""><strong><?php
                                        if($type == "company"){
                                            $total_kharcha=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col+$total_ex;
                                        }else{
                                            $total_kharcha=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col;
                                        }
                                        $Total= $total_coll-$total_kharcha; if($Total<0) echo '<span class="text-danger ddue">'.$Total.'  LOSS</span>'; else echo '<span class="text-success ddue">'.$Total.'  PROFIT</span>'; 
                                        ?></strong></td>
                                        </tr>                    
                             <?php
                                }
                            }
                                if (!empty($_GET['date'])){
                                    $query = "SELECT  SUM(`1l`), SUM(`500ml`), SUM(`250ml`), SUM(`2l`), SUM(`coldd`),SUM(`d_cash`),sum(`d_online`) ,SUM(`udari`),SUM(`Name`) FROM `daily_challan` WHERE  `date` LIKE '$Searchmonth' ORDER BY `date` ASC;";
                                 }else{
                                    $query = "SELECT  SUM(`1l`), SUM(`500ml`), SUM(`250ml`), SUM(`2l`), SUM(`coldd`),SUM(`d_cash`),sum(`d_online`) ,SUM(`udari`),SUM(`Name`) FROM `daily_challan` WHERE  date BETWEEN '$from' AND '$to' ORDER BY `date` ASC;";
                                }
                                $query_run = mysqli_query($conn,$query);           
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($row = mysqli_fetch_array($query_run))
                                    {
                                        $t_onel = $row['SUM(`1l`)'];
                                        $t_halfml = $row['SUM(`500ml`)'];
                                        $t_quatml = $row['SUM(`250ml`)'];
                                        $t_twol = $row['SUM(`2l`)'];
                                        $t_coldd = $row['SUM(`coldd`)'];
                                        $t_d_cash = $row['SUM(`d_cash`)'];
                                        $t_d_online = $row['sum(`d_online`)'];
                                        $t_d_udari = $row['SUM(`udari`)'];
                                        $t_d_Name = $row['SUM(`Name`)'];
                                ?>
                                    <tr>
                                        <th>Total : </th>
                                        <td></td>
                                        <th><?php echo $t_onel;?></th>
                                        <th><?php echo $t_halfml;?></th>
                                        <th><?php echo $t_quatml;?></th>
                                        <th><?php echo $t_twol;?></th>
                                        <th><?php echo $t_coldd;?></th>
                                        <th><?php echo $t_onel+$t_halfml+$t_quatml+$t_twol+$t_coldd ;?></th>
                                        <?php
                                        if($type == "self"){
                                        ?>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <?php
                                            }
                                        ?>
                                        <th><?php $tP_1l=$t_onel*$r_onel;$tP_500ml= $t_halfml*$r_halfml ; $tP_250l= $t_quatml*$r_quatml ;$tP_2l= $t_twol*$r_twol ; $tP_col= $t_coldd*$r_coldd ;  $total_am=$tP_1l+$tP_250l+$tP_500ml+$tP_2l+$tP_col; echo $total_am;?>
                                        </th>
                                        <th><?php echo $t_d_cash+$t_d_online+$t_d_udari+$t_d_Name;?></th>
                                        <?php if($type == "company"){ ?>
                                        <th></th>
                                        <?php } ?>
                                        <th><?php echo $t_d_udari;?></th>
                                        <?php
                                        if($type == "company"){
                                        ?>
                                        <th><?php echo $t_d_Name;?></th>
                                        <?php
                                            }
                                        ?>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                    <th id="dp"></th>
                                    </tr>
                                    <?php
                                    }
                                }
                                    ?>
<?php
                        }else{  //All Employee
                            if($type == "company"){
                                if (!empty($_GET['date'])){
                                    $query = "SELECT * FROM `daily_challan` dc INNER JOIN daily_exp de ON dc.Sequence_no = de.Sequence_no AND dc.challan_no = de.challan_no AND dc.date = de.date AND dc.gadi_no= de.gadi_no WHERE dc.salesman='$namme' OR dc.driver='$namme' AND dc.date LIKE '$Searchmonth' ORDER BY dc.challan_no ASC;";
                                }else{
                                    $query = "SELECT * FROM `daily_challan` dc INNER JOIN daily_exp de ON dc.Sequence_no = de.Sequence_no AND dc.challan_no = de.challan_no AND dc.date = de.date AND dc.gadi_no= de.gadi_no WHERE dc.salesman='$namme' OR dc.driver='$namme' AND dc.date BETWEEN '$from' AND '$to' ORDER BY dc.challan_no ASC;"; 
                                }
                                $query_run = mysqli_query($conn,$query);           
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($row = mysqli_fetch_array($query_run))
                                    {
                                            $Sequence_no = $row['Sequence_no'];
                                            $onel = $row['1l'];
                                            $halfml = $row['500ml'];
                                            $quatml = $row['250ml'];
                                            $twol = $row['2l'];
                                            $coldd = $row['coldd'];
                                            $challan_no = $row['challan_no'];
                                            $d_cash = $row['d_cash'];
                                            $d_online = $row['d_online'];
                                            $udari = $row['udari'];
                                            $gadi_no = $row['gadi_no'];
                                            $gadi_exp = $row['gadi_exp'];
                                            $diesel = $row['diesel'];
                                            $toll = $row['toll'];
                                            $s_man = $row['s_man'];
                                            $chai_pani = $row['chai_pani'];
                                            $other_exp = $row['other_exp'];
                                            $Name = $row['Name'];
                                            $ddate = $row['date']; 
                                            $newDate = date("d-m-Y", strtotime($ddate)); 

                                            $query1 = "SELECT *  FROM `rate` WHERE `date` <= '$ddate' ORDER BY id DESC LIMIT 1;";
                                            $query_run1 = mysqli_query($conn, $query1);
                                                $row = mysqli_fetch_array($query_run1);
                                                    $r_onel = $row['1l'];
                                                    $r_halfml = $row['500ml'];
                                                    $r_quatml = $row['250ml'];
                                                    $r_twol = $row['2l'];
                                                    $r_coldd = $row['col'];
                                        ?>
                                            <tr>
                                                <td><?php echo $newDate ;?></td>
                                                <td><?php echo $challan_no ;?></td>
                                                <td><?php echo $onel ;?> </td>
                                                <td><?php echo $halfml ;?> </td>
                                                <td><?php echo $quatml ;?> </td>
                                                <td><?php echo $twol ;?></td>
                                                <td><?php echo $coldd ;?></td>
                                                <td><?php echo $onel+$halfml+$quatml+$twol+$coldd ;?></td>
                                                <?php
                                                if($type == "self"){
                                                ?>
                                                <td><?php echo $r_onel ;?> </td>
                                                <td><?php echo $r_halfml ;?> </td>
                                                <td><?php echo $r_quatml ;?> </td>
                                                <td><?php echo $r_twol ;?></td>
                                                <td><?php echo $r_coldd ;?></td>
                                                <?php
                                                    }
                                                ?>
                                                <td><?php $P_1l=$onel*$r_onel;$P_500ml= $halfml*$r_halfml ; $P_250l= $quatml*$r_quatml ;$P_2l= $twol*$r_twol ; $P_col= $coldd*$r_coldd ;  $total_ammt=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col; echo $total_ammt;?>
                                                </td>

                                                <td><?php $total_coll = $d_cash+$d_online+$udari+$Name ; echo $total_coll;?></td>
                                                <?php if($type == "company"){ ?>
                                                <td><?php $total_ex = $gadi_exp+$diesel+$toll+$s_man+$chai_pani+$other_exp; echo $total_ex+$P_1l+$P_250l+$P_500ml+$P_2l+$P_col ;?>
                                                </td>
                                                <?php } ?>
                                                <td><?php echo $udari ;?></td>

                                                <?php
                                                if($type == "company"){
                                                ?>
                                                <td><?php echo $Name ;?></td>
                                                <?php
                                                    }
                                                ?>
                                        <?php

                                            $query_credit = "SELECT * FROM daily_credit WHERE  Sequence_no='$Sequence_no' AND emp_name='$namme' AND challan_no='$challan_no' AND date = '$ddate'";
                                            $query_run_credit = mysqli_query($conn, $query_credit);
                                            if (mysqli_num_rows($query_run_credit) > 0) {
                                                while ($row_credit = mysqli_fetch_array($query_run_credit)) {
                                                    $emp_name = $row_credit['emp_name'];
                                                    $mt = $row_credit['mt'];
                                                    $et = $row_credit['et'];
                                                    $wate = $row_credit['wate'];
                                                    $new_party = $row_credit['new_party'];
                                                    $total_box = $row_credit['total_box'];
                                                    $trip1 = $row_credit['trip1/2'];
                                                    $b = $row_credit['b/c'];
                                                    $dress = $row_credit['dress'];
                                                    $max_profit = $row_credit['max_profit'];
                                                    $max_average = $row_credit['max_average'];
                                                    $role = $row_credit['role'];
                                                    $total_credit = $mt + $et + $wate + $new_party + $total_box + $trip1 + $b + $dress + $max_profit + $max_average;
                                                    ?>
                                                    <td><?php echo $total_credit ;?></td>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        <td class=""><strong><?php
                                        $total_kharcha=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col+$total_ex;
                                        $Total= $total_coll-$total_kharcha; if($Total<0) echo '<span class="text-danger ddue">'.$Total.'  LOSS</span>'; else echo '<span class="text-success ddue">'.$Total.'  PROFIT</span>'; 
                                        ?></strong></td>
                                    </tr>
    
                            <?php
                                }
                            }
                            }else{ //company
                                if (!empty($_GET['date'])){
                                    $query = "SELECT * FROM `daily_challan` WHERE salesman='$namme' AND date LIKE '$Searchmonth' ORDER BY challan_no ASC;";
                                    }else{
                                    $query = "SELECT * FROM `daily_challan` WHERE salesman='$namme' AND date BETWEEN '$from' AND '$to' ORDER BY challan_no ASC;"; 
                                }
                                $query_run = mysqli_query($conn,$query);           
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($row = mysqli_fetch_array($query_run))
                                    {
                                    $Sequence_no = $row['Sequence_no'];
                                    $onel = $row['1l'];
                                    $halfml = $row['500ml'];
                                    $quatml = $row['250ml'];
                                    $twol = $row['2l'];
                                    $coldd = $row['coldd'];
                                    $challan_no = $row['challan_no'];
                                    $d_cash = $row['d_cash'];
                                    $d_online = $row['d_online'];
                                    $udari = $row['udari'];
                                    $gadi_no = $row['gadi_no'];
                                    $Name = $row['Name'];
                                    $ddate = $row['date']; 
                                    $newDate = date("d-m-Y", strtotime($ddate));

                                    $query1 = "SELECT *  FROM `rate` WHERE `date` <= '$ddate' ORDER BY id DESC LIMIT 1;";
                                    $query_run1 = mysqli_query($conn, $query1);
                                        $row = mysqli_fetch_array($query_run1);
                                            $r_onel = $row['1l'];
                                            $r_halfml = $row['500ml'];
                                            $r_quatml = $row['250ml'];
                                            $r_twol = $row['2l'];
                                            $r_coldd = $row['col'];
                                     ?>
                                    <tr>
                                        <td><?php echo $newDate ;?></td>
                                        <td><?php echo $challan_no ;?></td>
                                        <td><?php echo $onel ;?> </td>
                                        <td><?php echo $halfml ;?> </td>
                                        <td><?php echo $quatml ;?> </td>
                                        <td><?php echo $twol ;?></td>
                                        <td><?php echo $coldd ;?></td>
                                        <td><?php echo $onel+$halfml+$quatml+$twol+$coldd ;?></td>
                                        <?php
                                        if($type == "self"){
                                        ?>
                                        <td><?php echo $r_onel ;?> </td>
                                        <td><?php echo $r_halfml ;?> </td>
                                        <td><?php echo $r_quatml ;?> </td>
                                        <td><?php echo $r_twol ;?></td>
                                        <td><?php echo $r_coldd ;?></td>
                                        <?php
                                            }
                                        ?>
                                        <td><?php $P_1l=$onel*$r_onel;$P_500ml= $halfml*$r_halfml ; $P_250l= $quatml*$r_quatml ;$P_2l= $twol*$r_twol ; $P_col= $coldd*$r_coldd ;  $total_ammt=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col; echo $total_ammt;?>
                                        </td>
        
                                        <td><?php $total_coll = $d_cash+$d_online+$udari+$Name ; echo $total_coll;?></td>
                                        <?php if($type == "company"){ ?>
                                        <td><?php $total_ex = $gadi_exp+$diesel+$toll+$s_man+$chai_pani+$other_exp; echo $total_ex+$P_1l+$P_250l+$P_500ml+$P_2l+$P_col ;?>
                                        </td>
                                        <?php } ?>
                                        <td><?php echo $udari ;?></td>
        
                                        <?php
                                        if($type == "company"){
                                        ?>
                                        <td><?php echo $Name ;?></td>
                                        <?php
                                            }
                                        ?>
                                        <td class=""><strong><?php
                                        $total_kharcha=$P_1l+$P_250l+$P_500ml+$P_2l+$P_col;
                                        $Total= $total_coll-$total_kharcha; if($Total<0) echo '<span class="text-danger ddue">'.$Total.'  LOSS</span>'; else echo '<span class="text-success ddue">'.$Total.'  PROFIT</span>'; 
                                        ?></strong></td>
                                    </tr>
                                        <?php
            
                                    }
                                }
                            
                            } //company

                            if (!empty($_GET['date'])){ 

                                $query = "SELECT  SUM(`1l`), SUM(`500ml`), SUM(`250ml`), SUM(`2l`), SUM(`coldd`),SUM(`d_cash`),sum(`d_online`) ,SUM(`udari`),SUM(`Name`) FROM `daily_challan` WHERE `salesman`='$namme' OR `driver`='$namme' AND `date` LIKE '$Searchmonth' ORDER BY `date` ASC;";
                                }else{
                                 $query = "SELECT  SUM(`1l`), SUM(`500ml`), SUM(`250ml`), SUM(`2l`), SUM(`coldd`),SUM(`d_cash`),sum(`d_online`) ,SUM(`udari`),SUM(`Name`) FROM `daily_challan` WHERE `salesman`='$namme' OR `driver`='$namme' AND date BETWEEN '$from' AND '$to' ORDER BY `date` ASC;";
                                
                            }
                            $query_run = mysqli_query($conn,$query);           
                            if(mysqli_num_rows($query_run) > 0)
                            {
                                while($row = mysqli_fetch_array($query_run))
                                {
                                    $t_onel = $row['SUM(`1l`)'];
                                    $t_halfml = $row['SUM(`500ml`)'];
                                    $t_quatml = $row['SUM(`250ml`)'];
                                    $t_twol = $row['SUM(`2l`)'];
                                    $t_coldd = $row['SUM(`coldd`)'];
                                    $t_d_cash = $row['SUM(`d_cash`)'];
                                    $t_d_online = $row['sum(`d_online`)'];
                                    $t_d_udari = $row['SUM(`udari`)'];
                                    $t_d_Name = $row['SUM(`Name`)']; 
                                     
                            ?>
                                <tr>
                                    <th>Total : </th>
                                    <td></td>
                                    <th><?php echo $t_onel;?></th>
                                    <th><?php echo $t_halfml;?></th>
                                    <th><?php echo $t_quatml;?></th>
                                    <th><?php echo $t_twol;?></th>
                                    <th><?php echo $t_coldd;?></th>
                                    <th><?php echo $t_onel+$t_halfml+$t_quatml+$t_twol+$t_coldd ;?></th>
                                    <?php
                                    if($type == "self"){
                                    ?>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <?php
                                        }
                                    ?>
                                    <th><?php $tP_1l=$t_onel*$r_onel;$tP_500ml= $t_halfml*$r_halfml ; $tP_250l= $t_quatml*$r_quatml ;$tP_2l= $t_twol*$r_twol ; $tP_col= $t_coldd*$r_coldd ;  $total_am=$tP_1l+$tP_250l+$tP_500ml+$tP_2l+$tP_col; echo $total_am;?>
                                    </th>
                                    <th><?php echo $t_d_cash+$t_d_online+$t_d_udari+$t_d_Name;?></th>
                                    <?php if($type == "company"){ ?>
                                    <th></th>
                                    <?php } ?>
                                    <th><?php echo $t_d_udari;?></th>
                                    <?php
                                    if($type == "company"){
                                    ?>
                                    <th><?php echo $t_d_Name;?></th>
                                    <?php
                                        }
                                    ?>

                                    <?php
                                    if($type == "company"){
                                        if (!empty($_GET['date'])){
                                                $query_credit = "SELECT 
                                                sum(`mt`) as mt,sum(`et`) as et,sum(`wate`) as wate,sum(`new_party`) as new_party,sum(`total_box`) as total_box,sum(`trip1/2`) as trip1,sum(`b/c`) as b,sum(`dress`) as dress,sum(`max_profit`) as max_profit,sum(`max_average`) as max_average
                                                FROM `daily_credit`  WHERE  emp_name='$namme' AND month(`date`)='$month'";
                                                }else{
                                                $query_credit = "SELECT 
                                                sum(`mt`) as mt,sum(`et`) as et,sum(`wate`) as wate,sum(`new_party`) as new_party,sum(`total_box`) as total_box,sum(`trip1/2`) as trip1,sum(`b/c`) as b,sum(`dress`) as dress,sum(`max_profit`) as max_profit,sum(`max_average`) as max_average
                                                FROM `daily_credit`  WHERE  emp_name='$namme' AND date BETWEEN '$from' AND '$to' ";
                                        }
                                        $query_run_credit = mysqli_query($conn, $query_credit);
                                        if (mysqli_num_rows($query_run_credit) > 0) {
                                            while ($row_credit = mysqli_fetch_array($query_run_credit)) {
                                                $mt = $row_credit['mt'];
                                                $et = $row_credit['et'];
                                                $wate = $row_credit['wate'];
                                                $new_party = $row_credit['new_party'];
                                                $total_box = $row_credit['total_box'];
                                                $trip1 = $row_credit['trip1'];
                                                $b = $row_credit['b'];
                                                $dress = $row_credit['dress'];
                                                $max_profit = $row_credit['max_profit'];
                                                $max_average = $row_credit['max_average'];
                                                $total_credit = $mt + $et + $wate + $new_party + $total_box + $trip1 + $b + $dress + $max_profit + $max_average;
                                                ?>
                                            <td><?php echo $total_credit ?></td>
                                        <?php
                                                    }
                                                }
                                        }
                                    }
                                }
                                        ?>


                                <th id="dp"></th>
                            </tr>

                        <?php
                        } //All Employee
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

        <?php      }  // get  ?>

        <div style="width: 50%;">
            <div style="display: flex;justify-content: center;gap: 2rem;margin-top: 2rem;" class=" ">
                <button onclick="myprint()" type="button" class="btn btn-success w-25">Print</button>
                <a href="m_report.php" class="w-25"><button type="button"
                        class="btn btn-danger w-100">Cancel</button></a>
            </div>
        </div>
    </main>
    <footer></footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script>
    const elements = document.getElementsByClassName("ddue");
    const dp = document.getElementById("dp");
    var t_due = 0;
    for (let i = 0; i < elements.length; i++) {
        let num = parseInt(elements[i].innerHTML);
        t_due = t_due + num;
    }
    // dp.innerHTML = t_due;
    if (t_due > 0) {
        dp.innerHTML = '<span class="text-success">' + t_due + ' PROFIT </span>';
    } else {
        dp.innerHTML = '<span class="text-danger">' + t_due + ' LOSS </span>';
    }

    function myduevalue() {
        const dueinput = document.getElementById("due").value;
        let num12 = parseInt(dueinput);
        let temptotal = t_due + num12;
        if (temptotal > 0) {
            dp.innerHTML = '<span class="text-success">' + tempnam + ' PROFIT </span>';
        } else {
            dp.innerHTML = '<span class="text-danger">' + tempnam + ' LOSS </span>';
        }
    }

    function myprint() {

        var backup = document.body.innerHTML;
        var content = document.getElementById("printcontent").innerHTML;

        document.body.innerHTML = content;
        window.print();
        document.body.innerHTML = backup;

    }
    </script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/2.1.3/js/dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        var table = $('#example').DataTable({
            paging: false

        });
    });
    </script>
</body>

</html>
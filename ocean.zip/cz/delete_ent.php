<?php
include("session.php"); 

include("db.php");
$active = 8;
if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }
?>


<div class="container">

    <div style="margin-left: 83px;margin-top: 40px;color: #808091;" class="row-1 d-flex ">
        <h4><strong> Delete Entry</strong></h4>
    </div>
    <div style=" display: flex; justify-content: center; margin-top: 2.5rem;">
        <form autocomplete="off" style="width: 100%;margin-bottom: 9rem;display: flex;justify-content: center;"
            method="get" action="del_tab.php">
            <div style="display:flex;width: 25%;margin-top: 4rem;gap: 1rem;flex-direction: column;">
                <div class="form-group">
                    <label for="gadiNo" style="margin-bottom: 8px;">Gadi no. :</label>
                    <input list="gadino" name="gadi_no" id="gadiNo" class="form-control" required>
                    <datalist id="gadino">
                        <?php 
                        $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
                        $query = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($query)){
                        ?>
                    <option value="<?php echo $row['gadi_no']; ?>" class="form-select"></option>
                        <?php  }?>
                    </datalist>
                </div>

                    <div class="form-group ">
                        <label for="exampleFormControlInput1" style="margin-bottom: 8px;">Month : </label>
                        <input type="month" name="date" class="form-control" id="exampleFormControlInput1" required>
                    </div>

                <div style="display: flex; justify-content: center;" class="row-1 d-flex ">
                    <button type="submit" class="btn btn-primary w-25">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
include("footer.php");
?>

<script>

  

    </script>
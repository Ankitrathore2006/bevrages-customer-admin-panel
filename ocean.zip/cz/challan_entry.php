<?php
include("session.php"); 

include("db.php");
$active = 6;
if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }
?>

<div class="container">

    <div style="margin-left: 83px;margin-top: 40px;color: #808091;" class="row-1 d-flex ">
        <h4><strong> Challan Entery</strong></h4>
    </div>
    <div style=" display: flex; justify-content: center; margin-top: 2.5rem;">
        <form style="width: 100%; margin-bottom: 9rem;" method="get" action="challan_entry1.php">
            <div style="margin-bottom: 2rem; width: 100%; display: flex; gap: 2rem; justify-content: space-evenly;">
            <div style="gap: 1rem; display: flex; flex-direction: column; width: 18rem;">
    <strong>EMPLOYEE DETAILS :</strong>
    <div class="form-group">
        <label for="employeeName" style="margin-bottom: 8px;">Employee Name:</label>
        <input list="staffid" name="employee_name" id="employeeName" class="form-control" required>
        <datalist id="staffid">
            <?php 
            $sql = "SELECT `emp_id`,`name` FROM `employee`;";
            $query = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($query)){
            ?>
            <option id="<?php echo $row['emp_id']; ?>" value="<?php echo $row['name']; ?>" class="form-select"></option>
            <?php  }?>
        </datalist>
    </div>
    <div class="form-group">
        <label for="date" style="margin-bottom: 8px;">Date:</label>
        <input type="date" name="date" class="form-control" id="date"required>
    </div>
   

    
</div>

<div style="gap: 1rem; display: flex; flex-direction: column; width: 18rem;">
    
    <div class="form-group">
        <label for="gadiNo" style="margin-bottom: 8px;">Gadi No.:</label>
        <input list="gadino" name="gadi_no" id="gadiNo" class="form-control" required>
        <datalist id="gadino">
            <?php 
            $sql = "SELECT `gadi_no` FROM `gadi_detail`;";
            $query = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($query)){
            ?>
           <option value="<?php echo $row['gadi_no']; ?>" class="form-select"></option>
            <?php  }?>
        </datalist>
    </div>
    <!-- <div class="form-group">
        <label for="Discount" style="margin-bottom: 8px;">Discount :</label>
        <input type="number" name="Discount" class="form-control" id="Discount"required>
    </div> -->
</div>

<!-- <div style="gap: 1rem; display: flex; flex-direction: column; width: 18rem;">
    <strong>RATES:</strong>
    <div class="form-group">
        <label for="oneLiterRate" style="margin-bottom: 8px;">1 liter Rate:</label>
        <input type="number" name="one_liter_rate" value="66" class="form-control" id="oneLiterRate">
    </div>
    <div class="form-group">
        <label for="halfLiterRate" style="margin-bottom: 8px;">500 ml Rate:</label>
        <input type="number" name="half_liter_rate" value="98" class="form-control" id="halfLiterRate">
    </div>
    <div class="form-group">
        <label for="quarterLiterRate" style="margin-bottom: 8px;">250 ml Rate:</label>
        <input type="number" name="quarter_liter_rate" value="114" class="form-control" id="quarterLiterRate">
    </div>
    <div class="form-group">
        <label for="twoLiterRate" style="margin-bottom: 8px;">2 liter Rate:</label>
        <input type="number" name="two_liter_rate" value="75" class="form-control" id="twoLiterRate">
    </div>
    <div class="form-group">
        <label for="coldDrinkRate" style="margin-bottom: 8px;">Cold Drink Rate:</label>
        <input type="number" name="cold_drink_rate" value="169" class="form-control" id="coldDrinkRate">
    </div>
</div> -->

                

            </div>
            <div style="display: flex; justify-content: center;" class="row-1 d-flex ">
                <button type="submit" class="btn btn-primary w-25">Submit</button>
            </div>

        </form>
    </div>
</div>
<?php
include("footer.php");
?>
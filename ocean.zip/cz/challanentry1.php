<?php
include("session.php"); 

include("db.php");

// Ensure the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {

    if($type == "company"){
        $Sequence_no = $_GET['Sequence_no'];
        $salesman = $_GET['salesman_name'];
        $gadi_no = $_GET['gadi_no'];
        $one_liter = $_GET['1l'];
        $half_liter = $_GET['500ml'];
        $quarter_liter = $_GET['250ml'];
        $two_liter = $_GET['2l'];
        $cold_drink = $_GET['coldd'];
        $challan_no = $_GET['challan_no'];
        $name = $_GET['Name'];
        $d_cash = $_GET['d_cash'];
        $d_online = $_GET['d_online'];
        $udhari = $_GET['udari'];
        $date = $_GET['date'];
        $type = $_GET['type'];
        $gadi_route = $_GET['gadi_route'];

        $driver = $_GET['driver_name'];
        $gadi_exp = $_GET['gadi_exp'];
        $diesel = $_GET['diesel'];
        $toll = $_GET['toll'];
        $s_man = $_GET['s_man'];
        $chai_pani = $_GET['chai_pani'];
        $other_exp = $_GET['other_exp'];

        
        $sql_exp = "UPDATE `daily_exp` SET `gadi_no`='$gadi_no', `challan_no`='$challan_no', `gadi_exp`='$gadi_exp', `diesel`='$diesel', `toll`='$toll', `s_man`='$s_man', `chai_pani`='$chai_pani', `other_exp`='$other_exp', `salesman_name`='$salesman', `driver_name`='$driver', `date`='$date' WHERE `Sequence_no` = '$Sequence_no'";
        $result_exp = mysqli_query($conn, $sql_exp);

        
        $sql_challan = "UPDATE `daily_challan` SET `salesman`='$salesman', `driver`='$driver', `1l`='$one_liter', `500ml`='$half_liter', `250ml`='$quarter_liter', `2l`='$two_liter', `coldd`='$cold_drink', `challan_no`='$challan_no', `gadi_no`='$gadi_no', `gadi_route`='$gadi_route', `d_cash`='$d_cash', `d_online`='$d_online', `udari`='$udhari', `Name`='$name', `date`='$date' WHERE `Sequence_no` = '$Sequence_no'";
        $result_challan = mysqli_query($conn, $sql_challan);

        if ($result_exp && $result_challan) {
            echo "<script>alert('Successfully Updated!'); window.location.href='edit_entry.php';</script>";
        } else {
            echo "<script>alert('Error: Unable to update records.')</script>";
        }

    } else {

        $Sequence_no = $_GET['Sequence_no'];
        $salesman = $_GET['salesman_name'];
        $gadi_no = $_GET['gadi_no'];
        $one_liter = $_GET['1l'];
        $half_liter = $_GET['500ml'];
        $quarter_liter = $_GET['250ml'];
        $two_liter = $_GET['2l'];
        $cold_drink = $_GET['coldd'];
        $challan_no = $_GET['challan_no'];
        $name = $_GET['Name'];
        $d_cash = $_GET['d_cash'];
        $d_online = $_GET['d_online'];
        $udhari = $_GET['udari'];
        $date = $_GET['date'];
        $type = $_GET['type'];
        $gadi_route = $_GET['gadi_route'];

        $sql_challan = "UPDATE `daily_challan` SET `salesman`='$salesman', `1l`='$one_liter', `500ml`='$half_liter', `250ml`='$quarter_liter', `2l`='$two_liter', `coldd`='$cold_drink', `challan_no`='$challan_no', `gadi_no`='$gadi_no', `gadi_route`='$gadi_route', `d_cash`='$d_cash', `d_online`='$d_online', `udari`='$udhari', `Name`='$name', `date`='$date' WHERE `Sequence_no` = '$Sequence_no'";
        $result_challan = mysqli_query($conn, $sql_challan);

        if ($result_challan) {
            echo "<script>alert('Successfully Updated!'); window.location.href='edit_entry.php';</script>";
        } else {
            echo "<script>alert('Error: Unable to update records.')</script>";
        }
    }
}
?>

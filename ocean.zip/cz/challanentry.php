<?php
include("session.php"); 

include("db.php");

// Ensure the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {

    // Collect and sanitize the input data
    $Sequence_no = mysqli_real_escape_string($conn, $_GET['Sequence_no']);
    $gadi_no = mysqli_real_escape_string($conn, $_GET['gadi_no']);
    $gadi_route = mysqli_real_escape_string($conn, $_GET['gadi_route']);
    $gadi_exp = mysqli_real_escape_string($conn, $_GET['gadi_exp']);
    $diesel = mysqli_real_escape_string($conn, $_GET['diesel']);
    $toll = mysqli_real_escape_string($conn, $_GET['toll']);
    $s_man = mysqli_real_escape_string($conn, $_GET['s_man']);
    $chai_pani = mysqli_real_escape_string($conn, $_GET['chai_pani']);
    $other_exp = mysqli_real_escape_string($conn, $_GET['other_exp']);
    $salesman_name = mysqli_real_escape_string($conn, $_GET['salesman_name']);
    $driver_name = mysqli_real_escape_string($conn, $_GET['driver_name']);
    $gadi_date = mysqli_real_escape_string($conn, $_GET['gadi_date']);
    $challan_no = mysqli_real_escape_string($conn, $_GET['challan_no']);
    $case = mysqli_real_escape_string($conn, $_GET['case']);
    $account = mysqli_real_escape_string($conn, $_GET['account']);
    $udhari = mysqli_real_escape_string($conn, $_GET['udhari']);
    $one_liter = mysqli_real_escape_string($conn, $_GET['one_liter']);
    $half_liter = mysqli_real_escape_string($conn, $_GET['half_liter']);
    $quarter_liter = mysqli_real_escape_string($conn, $_GET['quarter_liter']);
    $two_liter = mysqli_real_escape_string($conn, $_GET['two_liter']);
    $cold_drink = mysqli_real_escape_string($conn, $_GET['cold_drink']);
    $name = mysqli_real_escape_string($conn, $_GET['name']);

    $employee_name = mysqli_real_escape_string($conn, $_GET['employee_name']);

    if($employee_name == "NA"){

    // Insert into `daily_exp` table
    $sql_exp = "INSERT INTO `daily_exp`(`Sequence_no`,`gadi_no`,`challan_no`, `gadi_exp`, `diesel`, `toll`, `s_man`, `chai_pani`, `other_exp`, `salesman_name`, `driver_name`, `date`) 
                VALUES ('$Sequence_no','$gadi_no','$challan_no', '$gadi_exp', '$diesel', '$toll', '$s_man', '$chai_pani', '$other_exp', '$salesman_name', '$driver_name', '$gadi_date')";
    $result_exp = mysqli_query($conn, $sql_exp);

    // Insert into `daily_challan` table
    $sql_challan = "INSERT INTO `daily_challan`(`Sequence_no`,`type`,`salesman`,`driver`, `1l`, `500ml`, `250ml`, `2l`, `coldd`, `challan_no`, `gadi_no`, `gadi_route`, `d_cash`, `d_online`, `udari`, `Name`, `date`) 
                    VALUES ('$Sequence_no','company','$salesman_name','$driver_name', '$one_liter', '$half_liter', '$quarter_liter', '$two_liter', '$cold_drink', '$challan_no', '$gadi_no','$gadi_route', '$case', '$account', '$udhari','$name', '$gadi_date')";
    $result_challan = mysqli_query($conn, $sql_challan);
    // Validate results and provide feedback
    if ($result_exp && $result_challan) {
        echo "<script>
                alert('Successfully Added!');
                window.location.href='entry.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }

    }else{
 
    // Insert into `daily_challan` table
    $sql_challan = "INSERT INTO `daily_challan`(`Sequence_no`,`type`,`salesman`,`driver`, `1l`, `500ml`, `250ml`, `2l`, `coldd`, `challan_no`, `gadi_no`, `gadi_route`, `d_cash`, `d_online`, `udari`, `Name`, `date`) 
            VALUES ('$Sequence_no','self','$employee_name','NA', '$one_liter', '$half_liter', '$quarter_liter', '$two_liter', '$cold_drink', '$challan_no', '$gadi_no','$gadi_route', '$case', '$account', '$udhari','$name', '$gadi_date')";
    $result_challan = mysqli_query($conn, $sql_challan);

    // Validate results and provide feedback
    if ($result_challan) {
        echo "<script>
                alert('Successfully Added!');
                window.location.href='entry.php';
              </script>";
    } else {
        echo "<script>alert('Something went wrong...')</script>";
    }
    }

}
?>
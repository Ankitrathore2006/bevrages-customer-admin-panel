<?php
$active = 16;
include("session.php"); 
include("db.php");

if ($_SESSION['type'] == "admin") {
    include("header1.php");
} else {
    include("header.php");
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['w'])) {
        $date = $_GET['w'];
    } else {
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
            $month = substr($date, 5, 2);
            $Searchmonth = $date . '%';
        }
        if (!empty($_GET['from']) && !empty($_GET['to'])) {
            $from = $_GET['from'];
            $to = $_GET['to'];
            $newto = date("d-m-Y", strtotime($to));
            $newfrom = date("d-m-Y", strtotime($from));
        }
    }
?>

<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Employee performance</li>
    </ol>
</div>

<div class="row m-4">
    <div class="col-lg-5 mb-lg-0 mb-4">
        <div class="card justify-content-center align-items-center">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">
                        <?php
                        if ($date == 'c') {
                            echo "Employee Performance<br>";
                            echo date('d-m-Y', strtotime('monday this week')) . " to " . date('d-m-Y', strtotime('sunday this week'));
                        } elseif ($date == 'l') {
                            echo "Employee Performance<br>";
                            echo date('d-m-Y', strtotime('monday previous week')) . " to " . date('d-m-Y', strtotime('sunday previous week'));
                        } else {
                            echo "Employee Performance";
                            if (!empty($_GET['date'])) {
                                echo "<br><span><strong>Month: </strong>" . date("F", mktime(0, 0, 0, $month, 10)) . "</span>";
                                echo "<span><strong> Year: </strong>" . substr($date, 0, 4) . "</span>";
                            } elseif (!empty($_GET['from']) && !empty($_GET['to'])) {
                                echo "<br><span><strong>Date range: </strong> $newfrom - $newto</span>";
                            }
                        }
                        ?>
                    </h6>
                </div>
            </div>
            <div class="card-body w-75 p-3">
                <ul class="list-group">
                    <?php
                    if ($date == 'c') {
                        $startingdateofweek = date('Y-m-d', strtotime('monday this week'));
                        $lastdateofweek = date('Y-m-d', strtotime('sunday this week'));
                        $sql = "SELECT `emp_name`, 
                                    SUM(`mt`) + SUM(`et`) + SUM(`wate`) + SUM(`new_party`) + 
                                    SUM(`total_box`) + SUM(`trip1/2`) + SUM(`b/c`) + 
                                    SUM(`dress`) + SUM(`max_profit`) + SUM(`max_average`) AS total_credit
                                FROM `daily_credit`
                                WHERE `date` BETWEEN '$startingdateofweek' AND '$lastdateofweek'
                                GROUP BY `emp_name`
                                ORDER BY total_credit DESC;";
                    } elseif ($date == 'l') {
                        $startingdateofweek = date('Y-m-d', strtotime('monday previous week'));
                        $lastdateofweek = date('Y-m-d', strtotime('sunday previous week'));
                        $sql = "SELECT `emp_name`, 
                                    SUM(`mt`) + SUM(`et`) + SUM(`wate`) + SUM(`new_party`) + 
                                    SUM(`total_box`) + SUM(`trip1/2`) + SUM(`b/c`) + 
                                    SUM(`dress`) + SUM(`max_profit`) + SUM(`max_average`) AS total_credit
                                FROM `daily_credit`
                                WHERE `date` BETWEEN '$startingdateofweek' AND '$lastdateofweek'
                                GROUP BY `emp_name`
                                ORDER BY total_credit DESC;";
                    } else {
                        if (!empty($_GET['date'])) {
                            $sql = "SELECT `emp_name`, 
                                        SUM(`mt`) + SUM(`et`) + SUM(`wate`) + SUM(`new_party`) + 
                                        SUM(`total_box`) + SUM(`trip1/2`) + SUM(`b/c`) + 
                                        SUM(`dress`) + SUM(`max_profit`) + SUM(`max_average`) AS total_credit
                                    FROM `daily_credit`
                                    WHERE `date` LIKE '$Searchmonth'
                                    GROUP BY `emp_name`
                                    ORDER BY total_credit DESC;";
                        } elseif (!empty($_GET['from']) && !empty($_GET['to'])) {
                            $sql = "SELECT `emp_name`, 
                                        SUM(`mt`) + SUM(`et`) + SUM(`wate`) + SUM(`new_party`) + 
                                        SUM(`total_box`) + SUM(`trip1/2`) + SUM(`b/c`) + 
                                        SUM(`dress`) + SUM(`max_profit`) + SUM(`max_average`) AS total_credit
                                    FROM `daily_credit`
                                    WHERE `date` BETWEEN '$from' AND '$to'
                                    GROUP BY `emp_name`
                                    ORDER BY total_credit DESC;";
                        }
                    }

                    $query = mysqli_query($conn, $sql);
                    if (!$query) {
                        echo "<li class='list-group-item'>Error: " . mysqli_error($conn) . "</li>";
                    } else {
                        while ($row = mysqli_fetch_assoc($query)) {
                            ?>
                            <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                                <div class="d-flex align-items-center">
                                    <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                        <i class="fa-solid fa-user text-white opacity-10"></i>
                                    </div>
                                    <div class="d-flex flex-column">
                                        <h6 class="mb-1 text-dark text-sm"><?php echo $row['emp_name']; ?></h6>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <span class="text-xs"><span
                                            class="font-weight-bold"><?php echo $row['total_credit']; ?></span></span>
                                </div>
                            </li>
                            <?php
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php
}
include("footer.php");
?>

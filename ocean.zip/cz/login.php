<?php 
include('db.php'); 
 ?>
<?php
if (isset($_POST['name']) && isset($_POST['password']))
	{
		session_start();
		$username = mysqli_real_escape_string($conn,trim($_POST['name']));
		$password = mysqli_real_escape_string($conn,md5(trim($_POST['password'])));
		$query = "SELECT * FROM user WHERE username='$username' AND password='$password'";
		$result =$conn->query($query);
		$num_row = mysqli_num_rows($result);
		$row=$result->fetch_assoc();
		if( $num_row > 0 ) 
			{
				$_SESSION['id']=$row['username'];
				$_SESSION['type']=$row['type'];
				header('location: index.php');

				// if($row['type']=='user')
				// {
				// 	header('location:index.php');
				// }
								
			}
		else{ ?>
<script>
alert('Please check your username and password');
window.location.href = 'sign-in.php?fail';
</script>
<?php
			
	    }}
                 ?>
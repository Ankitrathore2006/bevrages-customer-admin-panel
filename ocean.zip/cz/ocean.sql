-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2025 at 03:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ocean`
--

-- --------------------------------------------------------

--
-- Table structure for table `daily_challan`
--

CREATE TABLE `daily_challan` (
  `id` int(11) NOT NULL,
  `Sequence_no` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `salesman` varchar(100) NOT NULL,
  `driver` varchar(100) NOT NULL,
  `1l` int(11) NOT NULL,
  `500ml` int(11) NOT NULL,
  `250ml` int(11) NOT NULL,
  `2l` int(11) NOT NULL,
  `coldd` int(11) NOT NULL,
  `challan_no` varchar(50) NOT NULL,
  `gadi_no` varchar(50) NOT NULL,
  `gadi_route` varchar(100) NOT NULL,
  `d_cash` int(11) NOT NULL,
  `d_online` int(11) NOT NULL,
  `udari` int(11) NOT NULL,
  `Name` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_challan`
--

INSERT INTO `daily_challan` (`id`, `Sequence_no`, `type`, `salesman`, `driver`, `1l`, `500ml`, `250ml`, `2l`, `coldd`, `challan_no`, `gadi_no`, `gadi_route`, `d_cash`, `d_online`, `udari`, `Name`, `date`) VALUES
(1, 1, 'company', 'ramkishan', 'rahul chouhan', 45, 45, 454, 345, 43, '1', '2895', 'gwa', 4567, 4567, 456, 5677, '2025-01-01'),
(2, 2, 'company', 'ashok', 'rohit yadav', 564, 654, 645, 65, 0, '2', '2895', 'ind', 43567, 34567, 3456, 546, '2025-01-02'),
(3, 3, 'self', 'plant sale', 'NA', 45, 54, 65, 78, 0, '0', '5991', 'na', 456, 3456, 435, 0, '2025-01-03'),
(4, 4, 'self', 'plant sale', 'NA', 456, 65, 5, 66, 0, '0', '7157', 'na', 67, 5675689, 0, 0, '2025-01-03'),
(5, 5, 'company', 'ramkishan', 'rohit yadav', 876, 786, 8786, 76, 0, '3', '7157', 'na', 5678, 546789, 0, 0, '2025-01-12'),
(6, 6, 'self', 'Ankit Rathore', 'NA', 56, 567, 57, 65, 5, '4', '5991', 'na', 56789, 56789, 5678, 0, '2025-01-19'),
(7, 7, 'company', 'ashok', 'ramkishan', 5678, 657, 657, 56, 7, '5', '8640', 'na', 4657, 4567, 0, 0, '2025-01-19'),
(8, 8, 'self', 'Ankit Rathore', 'NA', 65, 7656, 6, 56, 0, '6', '5991', 'ind', 65786, 567876, 0, 0, '2025-01-21'),
(9, 9, 'company', 'ashok', 'ramkishan', 567, 567, 567, 567, 0, '7', '2895', 'in', 56784567, 567, 546, 0, '2025-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `daily_credit`
--

CREATE TABLE `daily_credit` (
  `id` int(11) NOT NULL,
  `Sequence_no` int(11) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `gadi_no` varchar(50) NOT NULL,
  `challan_no` varchar(50) NOT NULL,
  `mt` int(2) NOT NULL,
  `et` int(2) NOT NULL,
  `wate` int(2) NOT NULL,
  `new_party` int(2) NOT NULL,
  `total_box` int(2) NOT NULL,
  `trip1/2` int(2) NOT NULL,
  `b/c` int(2) NOT NULL,
  `dress` int(2) NOT NULL,
  `max_profit` int(2) NOT NULL,
  `max_average` int(2) NOT NULL,
  `role` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_credit`
--

INSERT INTO `daily_credit` (`id`, `Sequence_no`, `emp_name`, `gadi_no`, `challan_no`, `mt`, `et`, `wate`, `new_party`, `total_box`, `trip1/2`, `b/c`, `dress`, `max_profit`, `max_average`, `role`, `date`) VALUES
(1, 1, 'ramkishan', '2895', '1', 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 'Salesman', '2025-01-01'),
(2, 1, 'rahul chouhan', '2895', '1', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Driver', '2025-01-01'),
(3, 2, 'ashok', '2895', '2', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Salesman', '2025-01-02'),
(4, 2, 'rohit yadav', '2895', '2', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Driver', '2025-01-02'),
(5, 5, 'ramkishan', '7157', '3', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Salesman', '2025-01-12'),
(6, 5, 'rohit yadav', '7157', '3', 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 'Driver', '2025-01-12'),
(7, 7, 'ashok', '8640', '5', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Salesman', '2025-01-19'),
(8, 7, 'ramkishan', '8640', '5', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Driver', '2025-01-19'),
(9, 9, 'ashok', '2895', '7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Salesman', '2025-01-21'),
(10, 9, 'ramkishan', '2895', '7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Driver', '2025-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `daily_exp`
--

CREATE TABLE `daily_exp` (
  `id` int(11) NOT NULL,
  `Sequence_no` int(11) NOT NULL,
  `gadi_no` varchar(50) NOT NULL,
  `challan_no` varchar(50) NOT NULL,
  `gadi_exp` int(11) NOT NULL,
  `diesel` int(11) NOT NULL,
  `toll` int(11) NOT NULL,
  `s_man` int(11) NOT NULL,
  `chai_pani` int(11) NOT NULL,
  `other_exp` int(11) NOT NULL,
  `salesman_name` varchar(100) NOT NULL,
  `driver_name` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_exp`
--

INSERT INTO `daily_exp` (`id`, `Sequence_no`, `gadi_no`, `challan_no`, `gadi_exp`, `diesel`, `toll`, `s_man`, `chai_pani`, `other_exp`, `salesman_name`, `driver_name`, `date`) VALUES
(1, 1, '2895', '1', 1000, 666, 30, 350, 0, 0, 'ramkishan', 'rahul chouhan', '2025-01-01'),
(2, 2, '2895', '2', 1000, 342, 54, 350, 54, 54, 'ashok', 'rohit yadav', '2025-01-02'),
(3, 5, '7157', '3', 1000, 657, 67567, 5, 7, 6, 'ramkishan', 'rohit yadav', '2025-01-12'),
(4, 7, '8640', '5', 1000, 456, 56, 350, 0, 0, 'ashok', 'ramkishan', '2025-01-19'),
(5, 9, '2895', '7', 1000, 678, 67, 350, 0, 0, 'ashok', 'ramkishan', '2025-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address` varchar(255) NOT NULL,
  `adhar` varchar(20) NOT NULL,
  `type` varchar(50) NOT NULL,
  `joining_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `name`, `mobile`, `address`, `adhar`, `type`, `joining_date`) VALUES
(1, 'rahul chouhan', '0', 'subh city', '0', 'company', '2022-01-01'),
(2, 'ramkishan', '0', 'subh city', '0', 'company', '2022-01-01'),
(3, 'mahesh waskel', '0', 'tejaji chok', '0', 'company', '2024-01-01'),
(4, 'ashok', '0', 'company', '0', 'company', '2022-01-01'),
(5, 'rohit yadav', '0', 'company', '0', 'company', '2023-01-01'),
(7, 'plant sale', '0', 'na', '0', 'self', '2025-01-19'),
(10, 'Ankit Rathore', '9174998662', 'na', '0', 'self', '2025-01-19');

-- --------------------------------------------------------

--
-- Table structure for table `gadi_detail`
--

CREATE TABLE `gadi_detail` (
  `id` int(11) NOT NULL,
  `gadi_no` varchar(50) NOT NULL,
  `company` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gadi_detail`
--

INSERT INTO `gadi_detail` (`id`, `gadi_no`, `company`, `date`) VALUES
(1, '3392', 'leland dost', '2018-01-01'),
(2, '2895', 'tata ace', '2018-01-01'),
(3, '1785', 'supro', '2024-06-01'),
(4, '5991', 'supro', '2024-01-01'),
(5, '7157', 'auto loding', '2022-01-01'),
(6, '8640', 'supro', '2020-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `rate`
--

CREATE TABLE `rate` (
  `id` int(11) NOT NULL,
  `1l` int(11) NOT NULL,
  `500ml` int(11) NOT NULL,
  `250ml` int(11) NOT NULL,
  `2l` int(11) NOT NULL,
  `col` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rate`
--

INSERT INTO `rate` (`id`, `1l`, `500ml`, `250ml`, `2l`, `col`, `date`) VALUES
(1, 65, 93, 110, 73, 150, '2014-01-19');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'user',
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `type`, `date`) VALUES
(1, 'admin', '63a9f0ea7bb98050796b649e85481845', 'admin', '2025-01-19'),
(2, 'ankit', '447d2c8dc25efbc493788a322f1a00e7', 'user', '2025-01-19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daily_challan`
--
ALTER TABLE `daily_challan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sequence_no` (`Sequence_no`);

--
-- Indexes for table `daily_credit`
--
ALTER TABLE `daily_credit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daily_exp`
--
ALTER TABLE `daily_exp`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sequence_no` (`Sequence_no`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `gadi_detail`
--
ALTER TABLE `gadi_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rate`
--
ALTER TABLE `rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daily_challan`
--
ALTER TABLE `daily_challan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `daily_credit`
--
ALTER TABLE `daily_credit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `daily_exp`
--
ALTER TABLE `daily_exp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `gadi_detail`
--
ALTER TABLE `gadi_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rate`
--
ALTER TABLE `rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

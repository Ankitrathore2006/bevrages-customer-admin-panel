<?php
include("session.php"); 

$active = 2;
include("db.php");
if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}
?>

<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Change Rates</li>
    </ol>
</div>


<div class="container d-flex justify-content-center align-items-center mt-5">

    <?php
     $query = "SELECT * FROM `rate`ORDER BY id DESC LIMIT 1;";
     $query_run = mysqli_query($conn,$query);           
     if(mysqli_num_rows($query_run) > 0)
     {
         while($row = mysqli_fetch_array($query_run)){
             $r_onel = $row['1l'];
             $r_halfml = $row['500ml'];
             $r_quatml = $row['250ml'];
             $r_twol = $row['2l'];
             $r_coldd = $row['col'];
    ?>
    <div class="col-lg-5">
        <form method="get" action="rates_change.php">
            <div class="card align-items-center">
                <div class="card-body p-3">
                    <ul class="list-group">
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-solid fa-bottle-water text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">1 Liter :</h6>
                                    <input type="number" value="<?php echo $r_onel; ?>" name="one_liter"
                                        class="form-control" id="oneLiter" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-solid fa-bottle-water text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">500 Liter :</h6>
                                    <input type="number" value="<?php echo $r_halfml; ?>" name="half_liter"
                                        class="form-control" id="halfLiter" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-solid fa-bottle-water text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">250 Liter :</h6>
                                    <input type="number" value="<?php echo $r_quatml; ?>" name="quarter_liter"
                                        class="form-control" id="quarterLiter" required>
                                </div>
                            </div>
                            
                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-solid fa-bottle-water text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">2 Liter :</h6>
                                    <input type="number" value="<?php echo $r_twol; ?>" name="two_liter"
                                        class="form-control" id="twoLiter" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-solid fa-bottle-water text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">cold Drink :</h6>
                                    <input type="number" value="<?php echo $r_coldd; ?>" name="cold_drink"
                                        class="form-control" id="coldDrink" required>
                                </div>
                            </div>

                        </li>

                        <div style="display: flex; justify-content: center;" class="row-1 d-flex mt-4">
                            <button type="submit" class="btn btn-primary w-75">Update</button>
                        </div>
                    </ul>

                </div>
            </div>
        </form>
    </div>




</div>
<?php
                    }
                    }
                
                ?>
<?php
include("footer.php");
?>
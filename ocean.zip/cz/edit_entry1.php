<?php
include("session.php"); 

$active = 6;
include("db.php");
if($_SESSION['type'] == "admin") {
    include("header1.php");
   }else{
    include("header.php");
}

if (isset($_GET['Sequence_no']) || isset($_GET['challan_no']) || isset($_GET['gadi_no']) || isset($_GET['date'])) {
    $sequence_no = $challan_no = $gadi_no = $date = "";
    $sequence_no = mysqli_real_escape_string($conn, $_GET['Sequence_no']);
    $challan_no = mysqli_real_escape_string($conn, $_GET['challan_no']);
    $gadi_no = mysqli_real_escape_string($conn, $_GET['gadi_no']);
    $date = mysqli_real_escape_string($conn, $_GET['date']);
?>

<div class="row mt-4 w-100">

    <div class="col-lg-11 mb-lg-0 m-5">
        <div class="card ">
            <div class="card-header pb-0 p-3">
                <div class="d-flex justify-content-between">
                    <h6 class="mb-2">Challans</h6>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-items-center ">
                    <thead class="mb-5">
                        <tr>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Action</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Challan No.</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Gadi No.</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Route</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Salesman</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Driver</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">1L</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">500ml</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">250ml</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">2L</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Cold Drinks</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Cash</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Online Payment</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Udari</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Name</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Date</p>
                                </div>
                            </td>
                            <!-- <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Type</p>
                                </div>
                            </td> -->
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Gadi Expense</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Diesel</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Toll</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">S.Man</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Chai Pani</p>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <p class="text-xs font-weight-bold mb-0">Other Expense</p>
                                </div>
                            </td>
                        </tr>

                    </thead>
                    <tbody>

                        <?php
                         $sql = "SELECT dc.`Sequence_no`, dc.`salesman`, dc.`driver`, dc.`1l`, dc.`500ml`, dc.`250ml`, dc.`2l`, dc.`coldd`, dc.`challan_no`, dc.`gadi_no`, dc.`gadi_route`, dc.`d_cash`, dc.`d_online`, dc.`udari`, dc.`Name`, dc.`date`, dc.`type`,  de.`gadi_exp`, de.`diesel`, de.`toll`, de.`s_man`, de.`chai_pani`, de.`other_exp` 
                         FROM `daily_challan` dc 
                         LEFT JOIN `daily_exp` de ON dc.`Sequence_no` = de.`Sequence_no` AND dc.`challan_no` = de.`challan_no` AND dc.`gadi_no` = de.`gadi_no` 
                         WHERE 1 = 1"; 
                         
                         // Adding conditions dynamically
                         if (!empty($sequence_no)) {
                             $sql .= " AND dc.`Sequence_no` = '" . mysqli_real_escape_string($conn, $sequence_no) . "'";
                         }
                         if (!empty($challan_no)) {
                             $sql .= " AND dc.`challan_no` = '" . mysqli_real_escape_string($conn, $challan_no) . "'";
                         }
                         if ($gadi_no !="NA") {
                             $sql .= " AND dc.`gadi_no` = '" . mysqli_real_escape_string($conn, $gadi_no) . "'";
                         }
                         if (!empty($date)) {
                             $sql .= " AND dc.`date` = '" . mysqli_real_escape_string($conn, $date) . "'";
                         }
                         
                         // Executing the query
                         $query = mysqli_query($conn, $sql);
                         if ($query && mysqli_num_rows($query) > 0) {
                             while($row = mysqli_fetch_assoc($query)){ 
                            
                        ?>
                        <tr>
                            <td>
                                <div class="text-center">

                                <a href="edit_entry2.php?Sequence_no=<?php echo $row['Sequence_no']; ?>"><button type="button" class="btn btn-secondary">Edit</button></a>
                                    <a href="delete_entry.php?id=<?php echo $row['Sequence_no']; ?>&type=<?php echo $row['type']; ?>&str=challan"><button
                                            type="button" class="btn btn-danger">Delete</button></a>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['challan_no']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['gadi_no']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['gadi_route']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['salesman']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['driver']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['1l']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['500ml']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['250ml']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['2l']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['coldd']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['d_cash']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['d_online']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['udari']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['Name']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['date']; ?></h6>
                                </div>
                            </td>
                            <!-- <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php// echo $row['type']; ?></h6>
                                </div>
                            </td> -->
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['gadi_exp']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['diesel']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['toll']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['s_man']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['chai_pani']; ?></h6>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <h6 class="text-sm mb-0"><?php echo $row['other_exp']; ?></h6>
                                </div>
                            </td>
                        </tr>

                        <?php } } else {
                            ?>
                            
                            <?php
                            echo "<tr><p class='text-center'>No records found for the provided details.</p></tr>";
                            }
                        } else {
                            echo "<p>Missing required parameters.</p>";
                        } ?>
                         <tr>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <!-- <td>
                                <div class="text-center">
                                </div>
                            </td> -->
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                </div>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


<?php
include("footer.php");
?>
<script>
document.getElementById('date-picker').max = new Date().toISOString().split('T')[0];
</script>
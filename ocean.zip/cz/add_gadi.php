<?php
$active = 4;
include("session.php"); 

include("db.php");

if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }
?>

<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Add Gadi</li>
    </ol>
</div>


<div class="row m-4">

    <div class="col-lg-5 mb-2">
        <form autocomplete="off" method="get" action="add_gadi1.php">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0">Enter Gadi Details : </h6>
                </div>
                <div class="card-body p-3 d-flex justify-content-center align-items-center">
                    <ul class="list-group">
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">Company Name :</h6>
                                    <input type="text" name="gadi_name" id="employeeName" class="form-control" required>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm">Gadi No. :</h6>
                                    <input type="text" name="gadi_no" class="form-control" id="challan_no" required>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-regular fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm"> Joining Date :</h6>
                                    <input type="date" name="j_date" class="form-control" id="date" style="width: 123%;" required>
                                </div>
                            </div>

                        </li>

                        <div style="display: flex; justify-content: center;" class="row-1 d-flex mt-4">
                            <button type="submit" class="btn btn-primary w-75">Submit</button>
                        </div>
                    </ul>

                </div>
            </div>
        </form>
    </div>


   

<div class="col-lg-5">
          <div class="card align-items-evenly">
            <div class="card-header pb-0 p-3">
              <h6 class="mb-0">Gadi : </h6>
            </div>
            <div class="card-body p-3 px-4">
              <ul class="list-group">

              <?php 
            $sql = "SELECT * FROM `gadi_detail`;";
            $query = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($query)){
            ?>
            
                <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                  <div class="d-flex align-items-center">
                    <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                      <i class="fa-solid fa-truck text-white opacity-10"></i>
                    </div>
                    <div class="d-flex flex-column">
                      <h6 class="mb-1 text-dark text-sm"><?php echo $row['gadi_no']; ?></h6>
                      <span class="text-xs"><span class="font-weight-bold"><?php $date = $row['date']; echo date("d-m-Y", strtotime($date));  ?></span></span>
                    </div>
                  </div>
                  <div class="d-flex">
                  <h6 class="mb-1 text-dark text-sm"><?php echo $row['company']; ?></h6>
                  </div>
                </li>

                <?php  }?>

              </ul>
            </div>
          </div>
        </div>

<?php
include("footer.php");
?>

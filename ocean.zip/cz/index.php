<?php
$todaydate = date("Y-m-d");
$curyaer = date("Y");
$newpyear=$curyaer."%";
$active = 1;

include("session.php");
include("db.php");

 if($_SESSION['type'] == "admin") {
     include("header1.php");
    }else{
     include("header.php");
 }

?>


<div class="path mx-4">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="javascript:;">Pages</a></li>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page">Dashboard</li>
    </ol>
</div>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Today's Money</p>
                                <?php
                                   $query = "SELECT SUM(`d_cash`) as c, SUM(`d_online`) as o, SUM(`udari`) as u, COUNT(`id`) as countt FROM `daily_challan` WHERE `date` = '$todaydate'";
                                   $query_run = mysqli_query($conn, $query);
                                   if ($query_run && mysqli_num_rows($query_run) > 0) {
                                       $row = mysqli_fetch_assoc($query_run);
                                       $total = ($row['c'] ?? 0) + ($row['o'] ?? 0) + ($row['u'] ?? 0);
                                   ?>

                                   <h5 class="font-weight-bolder">
                                       &#x20B9; <?php  echo (empty($total)) ? "0" : $total; ?>
                                   </h5>


                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-primary shadow-primary text-center rounded-circle">
                                <i class="ni ni-money-coins text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Today's Challans</p>
                                <h5 class="font-weight-bolder">

                                    <?php  echo (empty($row['countt'])) ? "0" : $row['countt']; 

                                  }?>
                                </h5>

                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-danger shadow-danger text-center rounded-circle">
                                <i class="ni ni-world text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Employees</p>
                                <?php
                                    $query = "SELECT COUNT(`emp_id`) as empl FROM `employee`;";
                                    $query_run = mysqli_query($conn,$query);           
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        $row = mysqli_fetch_array($query_run)
                                        
                                    ?>
                                <h5 class="font-weight-bolder">
                                    <?php  echo $row['empl']; 
                                    }?>
                                </h5>

                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-success shadow-success text-center rounded-circle">
                                <i class="ni ni-paper-diploma text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body p-3">
                    <div class="row">
                        <div class="col-8">
                            <div class="numbers">
                                <p class="text-sm mb-0 text-uppercase font-weight-bold">Yearly Sales</p>
                                <?php
                                    $query = "SELECT SUM(`d_cash`) as c,SUM(`d_online`) as o ,SUM(`udari`) as u,SUM(`Name`)as n FROM `daily_challan` WHERE `date` LIKE '$newpyear' ";
                                    $query_run = mysqli_query($conn,$query);           
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        $row = mysqli_fetch_array($query_run)
                                        
                                    ?>
                                <h5 class="font-weight-bolder">
                                    &#x20B9; <?php 
                                            $total = $row['c'] + $row['o'] + $row['u'] + $row['n']; 
                                            echo ($total == NULL) ? "0" : $total; 
                                    }
                                    ?>
                                </h5>

                            </div>
                        </div>
                        <div class="col-4 text-end">
                            <div class="icon icon-shape bg-gradient-warning shadow-warning text-center rounded-circle">
                                <i class="ni ni-cart text-lg opacity-10" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-lg-7 mb-lg-0 mb-4">
            <div class="card ">
                <div class="card-header pb-0 p-3">
                    <div class="d-flex justify-content-between">
                        <h6 class="mb-2">Today Gadies routes</h6>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center ">
                        <tbody>
                            <tr>
                                <td>

                                    <div class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">Challan No.</p>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">Gadi No.</p>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">Route </p>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">Salesman</p>
                                    </div>
                                </td>
                                <td class="align-middle text-sm">
                                    <div class="col text-center">
                                        <p class="text-xs font-weight-bold mb-0">Driver</p>
                                    </div>
                                </td>
                            </tr>

                            <?php
                            $sql = "SELECT `salesman`,`driver`,`challan_no`,`gadi_no`,`gadi_route` FROM `daily_challan` where `date` = '$todaydate' ;";
                                    $query = mysqli_query($conn,$sql);
                                    if (mysqli_num_rows($query) > 0) {
                                        while ($row = mysqli_fetch_array($query)) {
                                ?>
                            <tr>
                                <td>

                                    <div class="text-center">
                                        <h6 class="text-sm mb-0"><?php echo $row['challan_no']; ?></h6>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0"><?php echo $row['gadi_no']; ?></h6>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0"><?php echo $row['gadi_route']; ?></h6>
                                    </div>
                                </td>
                                <td class="align-middle text-sm">
                                    <div class="col text-center">
                                        <h6 class="text-sm mb-0"><?php echo $row['salesman']; ?></h6>
                                    </div>
                                </td>
                                <td class="align-middle text-sm">
                                    <div class="col text-center">
                                        <h6 class="text-sm mb-0"><?php echo $row['driver']; ?></h6>
                                    </div>
                                </td>
                            </tr>
                            <?php } }else{ ?>
                            <tr>
                                <td colspan="5">
                                    <div class="text-center">
                                        <h6 class="text-sm mb-0">
                                            Today not ganerated any challan.
                                        </h6>
                                    </div>
                                </td>
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header pb-0 p-3">
                    <?php 
                        ?>
                    <h6 class="mb-0">Weakly Employee Performance</h6>
                    <h6 class="mb-0">
                        <?php 
                        echo date('d-m-Y', strtotime('monday this week')) . " to " . date('d-m-Y', strtotime('sunday this week')); 
                        ?>
                    </h6>

                </div>
                <div class="card-body p-3">
                    <ul class="list-group">
                        <?php 
                       
                       $startingdateofweek = date('Y-m-d', strtotime('monday this week'));
                       $lastdateofweek = date('Y-m-d', strtotime('sunday this week')); 
                        $sql = " SELECT `emp_name`, 
                                    SUM(`mt`) + SUM(`et`) + SUM(`wate`) + SUM(`new_party`) + 
                                    SUM(`total_box`) + SUM(`trip1/2`) + SUM(`b/c`) + 
                                    SUM(`dress`) + SUM(`max_profit`) + SUM(`max_average`) AS total_credit
                                FROM `daily_credit` 
                                WHERE `date` BETWEEN '$startingdateofweek' AND '$lastdateofweek'
                                GROUP BY `emp_name`
                                ORDER BY total_credit DESC;";
                        $query = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($query)){
                    ?>
                        <li class="list-group-item border-0 d-flex justify-content-between ps-0 mb-2 border-radius-lg">
                            <div class="d-flex align-items-center">
                                <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                    <i class="fa-solid fa-user text-white opacity-10"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <h6 class="mb-1 text-dark text-sm"><?php echo $row['emp_name']; ?></h6>
                                </div>
                            </div>
                            <div class="d-flex">
                                <span class="text-xs"><span
                                        class="font-weight-bold"><?php echo $row['total_credit']; ?></span></span>
                            </div>
                        </li>

                        <?php }?>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <?php
include("footer.php");
?>